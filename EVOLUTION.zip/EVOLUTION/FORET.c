#include "BIBLIO.h"



void SIMULATION_TRES(struct OURS *ours, struct LOUP *loup, struct LYNX *lynx, struct AIGLE *aigle, struct CERF *cerf, struct SANGLIER *sanglier, struct FAUCON *faucon, struct CHEUVREUIL *chevreuil, struct SERPENT *serpent, struct BLAIREAU *blaireau, struct RENARD *renard, struct CHAUVE_SOURIS *chauve_souris, struct HERISSON *herisson, struct LAPIN *lapin, struct RONGEUR *rongeur, struct ECUREUIL *ecureuil, struct OISEAU *oiseau, struct GRENOUILLE *grenouille, struct ESCARGOT *escargot, struct LARVES *larves, struct INSECTES *insectes, struct FOURMIS *fourmis, struct VERRE_DE_TERRE *verre_de_terre, struct CHAMPIGNON *champignon, struct RACINE *racine, struct FRUIT *fruit, struct GRAINE *graine, struct HERBE *herbe, struct FEUILLE *feuille)
{
    printf("\n");
    printf("*******************************************************************************************************\n");
    printf("                                        DEBUT DE LA SIMULATION\n");
    printf("*******************************************************************************************************\n");
    printf("-------------------------------------------------------------------------------------------------------\n");
    printf("AVANT\n");
    printf("-------------------------------------------------------------------------------------------------------\n");
    printf("=> OURS                : %d\n", ours->Taille_AVANT);
    printf("=> LOUP                : %d\n", loup->Taille_AVANT);
    printf("=> LYNX                : %d\n", lynx->Taille_AVANT);
    printf("=> AIGLE               : %d\n", aigle->Taille_AVANT);
    printf("=> CERF                : %d\n", cerf->Taille_AVANT);
    printf("=> SANGLIER            : %d\n", sanglier->Taille_AVANT);
    printf("=> FAUCON              : %d\n", faucon->Taille_AVANT);
    printf("=> CHEUVREUIL          : %d\n", chevreuil->Taille_AVANT);
    printf("=> SERPENT             : %d\n", serpent->Taille_AVANT);
    printf("=> BLAIREAU            : %d\n", blaireau->Taille_AVANT);
    printf("=> RENARD              : %d\n", renard->Taille_AVANT);
    printf("=> CHAUVE_SOURIS       : %d\n", chauve_souris->Taille_AVANT);
    printf("=> HERISSON            : %d\n", herisson->Taille_AVANT);
    printf("=> LAPIN               : %d\n", lapin->Taille_AVANT);
    printf("=> RONGEUR             : %d\n", rongeur->Taille_AVANT);
    printf("=> ECUREUIL            : %d\n", ecureuil->Taille_AVANT);
    printf("=> OISEAU              : %d\n", oiseau->Taille_AVANT);
    printf("=> GRENOUILLE          : %d\n", grenouille->Taille_AVANT);
    printf("=> ESCARGOT            : %d\n", escargot->Taille_AVANT);
    printf("=> LARVES              : %d\n", larves->Taille_AVANT);
    printf("=> INSECTES            : %d\n", insectes->Taille_AVANT);
    printf("=> FOURMIS             : %d\n", fourmis->Taille_AVANT);
    printf("=> VERRE_DE_TERRE      : %d\n", verre_de_terre->Taille_AVANT);
    printf("=> CHAMPIGNON          : %d\n", champignon->Taille_AVANT);
    printf("=> RACINE              : %d\n", racine->Taille_AVANT);
    printf("=> FRUIT               : %d\n", fruit->Taille_AVANT);
    printf("=> GRAINE              : %d\n", graine->Taille_AVANT);
    printf("=> HERBE               : %d\n", herbe->Taille_AVANT);
    printf("=> FEUILLE             : %d\n", feuille->Taille_AVANT);
    printf("-------------------------------------------------------------------------------------------------------\n");
    printf("APRES\n");
    printf("-------------------------------------------------------------------------------------------------------\n");
//**********************************************************************************************************************

    ours->Taille_APRES          = ours->Taille_AVANT;
    loup->Taille_APRES          = loup->Taille_AVANT;
    lynx->Taille_APRES          = lynx->Taille_AVANT;
    aigle->Taille_APRES         = aigle->Taille_AVANT;
    cerf->Taille_APRES          = cerf->Taille_AVANT;
    sanglier->Taille_APRES      = sanglier->Taille_AVANT;
    faucon->Taille_APRES        = faucon->Taille_AVANT;
    chevreuil->Taille_APRES     = chevreuil->Taille_AVANT;
    serpent->Taille_APRES       = serpent->Taille_AVANT;
    blaireau->Taille_APRES      = blaireau->Taille_AVANT;
    renard->Taille_APRES        = renard->Taille_AVANT;
    chauve_souris->Taille_APRES = chauve_souris->Taille_AVANT;
    herisson->Taille_APRES      = herisson->Taille_AVANT;
    lapin->Taille_APRES         = lapin->Taille_AVANT;
    rongeur->Taille_APRES       = rongeur->Taille_AVANT;
    ecureuil->Taille_APRES      = ecureuil->Taille_AVANT;
    oiseau->Taille_APRES        = oiseau->Taille_AVANT;
    grenouille->Taille_APRES    = grenouille->Taille_AVANT;
    escargot->Taille_APRES      = escargot->Taille_AVANT;
    larves->Taille_APRES        = larves->Taille_AVANT;
    insectes->Taille_APRES      = insectes->Taille_AVANT;
    fourmis->Taille_APRES       = fourmis->Taille_AVANT;
    verre_de_terre->Taille_APRES= verre_de_terre->Taille_AVANT;
    champignon->Taille_APRES    = champignon->Taille_AVANT;
    racine->Taille_APRES        = racine->Taille_AVANT;
    fruit->Taille_APRES         = fruit->Taille_AVANT;
    graine->Taille_APRES        = graine->Taille_AVANT;
    herbe->Taille_APRES         = herbe->Taille_AVANT;
    feuille->Taille_APRES       = feuille->Taille_AVANT;

//**********************************************************************************************************************

    ours->Taille_APRES          = (int)(ours->Taille_AVANT * ((0.1*(float)cerf->Taille_AVANT/ours->Taille_AVANT) + (0.5*(float)fruit->Taille_AVANT /ours->Taille_AVANT) + (0.1*(float)blaireau->Taille_AVANT/ours->Taille_AVANT) + (0.1*(float)lapin->Taille_AVANT /ours->Taille_AVANT) + (0.1*(float)chevreuil->Taille_AVANT /ours->Taille_AVANT) + (0.1*(float)sanglier->Taille_AVANT /ours->Taille_AVANT)));

    loup->Taille_APRES          = (int)(loup->Taille_AVANT * ((0.1*(float)cerf->Taille_AVANT/loup->Taille_AVANT) + (0.1*(float)rongeur->Taille_AVANT /loup->Taille_AVANT) + (0.1*(float)renard->Taille_AVANT/loup->Taille_AVANT) + (0.2*(float)chevreuil->Taille_AVANT /loup->Taille_AVANT) + (0.1*(float)sanglier->Taille_AVANT /loup->Taille_AVANT) + (0.1*(float)blaireau->Taille_AVANT /loup->Taille_AVANT) + (0.2*(float)lapin->Taille_AVANT /loup->Taille_AVANT) + (0.1*(float)herisson->Taille_AVANT /loup->Taille_AVANT)));

    lynx->Taille_APRES          = (int)(lynx->Taille_AVANT * ((0.1*(float)cerf->Taille_AVANT/lynx->Taille_AVANT) + (0.2*(float)rongeur->Taille_AVANT /lynx->Taille_AVANT) + (0.1*(float)renard->Taille_AVANT/lynx->Taille_AVANT) + (0.1*(float)chevreuil->Taille_AVANT /lynx->Taille_AVANT) + (0.1*(float)sanglier->Taille_AVANT /lynx->Taille_AVANT) + (0.1*(float)oiseau->Taille_AVANT /lynx->Taille_AVANT) + (0.2*(float)lapin->Taille_AVANT /lynx->Taille_AVANT) + (0.1*(float)ecureuil->Taille_AVANT /lynx->Taille_AVANT)));

    aigle->Taille_APRES         = (int)(aigle->Taille_AVANT * ((0.1*(float)oiseau->Taille_AVANT/aigle->Taille_AVANT) + (0.1*(float)ecureuil->Taille_AVANT /aigle->Taille_AVANT) + (0.1*(float)rongeur->Taille_AVANT/aigle->Taille_AVANT) + (0.1*(float)lapin->Taille_AVANT /aigle->Taille_AVANT) + (0.1*(float)chauve_souris->Taille_AVANT /aigle->Taille_AVANT) + (0.1*(float)renard->Taille_AVANT /aigle->Taille_AVANT) + (0.1*(float)blaireau->Taille_AVANT /aigle->Taille_AVANT) + (0.1*(float)serpent->Taille_AVANT /aigle->Taille_AVANT) + (0.1*(float)chevreuil->Taille_AVANT /aigle->Taille_AVANT) + (0.1*(float)cerf->Taille_AVANT /aigle->Taille_AVANT)));

    cerf->Taille_APRES          = (int)(cerf->Taille_AVANT * ((0.6*(float)herbe->Taille_AVANT/cerf->Taille_AVANT) + (0.4*(float)feuille->Taille_AVANT/cerf->Taille_AVANT)));

    sanglier->Taille_APRES      = (int)(sanglier->Taille_AVANT * ((0.1*(float)feuille->Taille_AVANT/sanglier->Taille_AVANT) + (0.2*(float)fruit->Taille_AVANT/sanglier->Taille_AVANT) + (0.1*(float)herbe->Taille_AVANT/sanglier->Taille_AVANT) + (0.3*(float)racine->Taille_AVANT/sanglier->Taille_AVANT) + (0.3*(float)champignon->Taille_AVANT/sanglier->Taille_AVANT)));

    faucon->Taille_APRES        = (int)(faucon->Taille_AVANT * ((0.1*(float)grenouille->Taille_AVANT/faucon->Taille_AVANT) + (0.2*(float)oiseau->Taille_AVANT /faucon->Taille_AVANT) + (0.1*(float)ecureuil->Taille_AVANT/faucon->Taille_AVANT) + (0.3*(float)rongeur->Taille_AVANT /faucon->Taille_AVANT) + (0.1*(float)lapin->Taille_AVANT /faucon->Taille_AVANT) + (0.1*(float)chauve_souris->Taille_AVANT /faucon->Taille_AVANT) + (0.1*(float)serpent->Taille_AVANT /faucon->Taille_AVANT)));

    chevreuil->Taille_APRES     = (int)(chevreuil->Taille_AVANT * ((0.5*(float)herbe->Taille_AVANT/chevreuil->Taille_AVANT) + (0.5*(float)feuille->Taille_AVANT/chevreuil->Taille_AVANT)));

    serpent->Taille_APRES       = (int)(serpent->Taille_AVANT * ((0.5*(float)rongeur->Taille_AVANT/serpent->Taille_AVANT) + (0.2*(float)grenouille->Taille_AVANT /serpent->Taille_AVANT) + (0.3*(float)oiseau->Taille_AVANT/serpent->Taille_AVANT) ));

    blaireau->Taille_APRES      = (int)(blaireau->Taille_AVANT * ((0.1*(float)herisson->Taille_AVANT/blaireau->Taille_AVANT) + (0.1*(float)champignon->Taille_AVANT /blaireau->Taille_AVANT) + (0.1*(float)verre_de_terre->Taille_AVANT/blaireau->Taille_AVANT) + (0.1*(float)fruit->Taille_AVANT/blaireau->Taille_AVANT) + (0.1*(float)insectes->Taille_AVANT/blaireau->Taille_AVANT) + (0.1*(float)escargot->Taille_AVANT/blaireau->Taille_AVANT) + (0.1*(float)grenouille->Taille_AVANT/blaireau->Taille_AVANT) + (0.1*(float)oiseau->Taille_AVANT/blaireau->Taille_AVANT)+ (0.1*(float)oiseau->Taille_AVANT/blaireau->Taille_AVANT)+ (0.1*(float)lapin->Taille_AVANT/blaireau->Taille_AVANT)));

    renard->Taille_APRES        = (int)(renard->Taille_AVANT * ((0.2*(float)grenouille->Taille_AVANT/renard->Taille_AVANT) + (0.2*(float)oiseau->Taille_AVANT /renard->Taille_AVANT) + (0.1*(float)ecureuil->Taille_AVANT/renard->Taille_AVANT) + (0.2*(float)rongeur->Taille_AVANT/renard->Taille_AVANT) + (0.1*(float)lapin->Taille_AVANT/renard->Taille_AVANT) + (0.1*(float)herisson->Taille_AVANT/renard->Taille_AVANT) + (0.1*(float)chauve_souris->Taille_AVANT/renard->Taille_AVANT) ));

    chauve_souris->Taille_APRES = (int)(chauve_souris->Taille_AVANT * ((1*(float)insectes->Taille_AVANT/chauve_souris->Taille_AVANT)));

    herisson->Taille_APRES      = (int)(herisson->Taille_AVANT * ((0.2*(float)insectes->Taille_AVANT/herisson->Taille_AVANT) + (0.3*(float)escargot->Taille_AVANT /herisson->Taille_AVANT) + (0.2*(float)serpent->Taille_AVANT/herisson->Taille_AVANT) + (0.3*(float)verre_de_terre->Taille_AVANT/herisson->Taille_AVANT) ));

    lapin->Taille_APRES         = (int)(lapin->Taille_AVANT * ((0.2*(float)herbe->Taille_AVANT/lapin->Taille_AVANT) + (0.2*(float)feuille->Taille_AVANT /lapin->Taille_AVANT) + (0.3*(float)fruit->Taille_AVANT/lapin->Taille_AVANT) + (0.3*(float)graine->Taille_AVANT/lapin->Taille_AVANT)));

    rongeur->Taille_APRES       = (int)(rongeur->Taille_AVANT * ((0.2*(float)insectes->Taille_AVANT/rongeur->Taille_AVANT) + (0.1*(float)feuille->Taille_AVANT /rongeur->Taille_AVANT) + (0.2*(float)fruit->Taille_AVANT/rongeur->Taille_AVANT) + (0.3*(float)graine->Taille_AVANT/rongeur->Taille_AVANT)+ (0.2*(float)racine->Taille_AVANT/rongeur->Taille_AVANT)));

    ecureuil->Taille_APRES      = (int)(ecureuil->Taille_AVANT * ((0.5*(float)fruit->Taille_AVANT/ecureuil->Taille_AVANT) + (0.5*(float)graine->Taille_AVANT /ecureuil->Taille_AVANT)));

    oiseau->Taille_APRES        = (int)(oiseau->Taille_AVANT * ((0.4*(float)larves->Taille_AVANT/oiseau->Taille_AVANT) + (0.3*(float)graine->Taille_AVANT/oiseau->Taille_AVANT) + (0.2*(float)fruit->Taille_AVANT/oiseau->Taille_AVANT) + (0.1*(float)verre_de_terre->Taille_AVANT /oiseau->Taille_AVANT)));

    grenouille->Taille_APRES    = (int)(grenouille->Taille_AVANT * ((0.5*(float)insectes->Taille_AVANT/grenouille->Taille_AVANT) + (0.5*(float)larves->Taille_AVANT /grenouille->Taille_AVANT)));

    escargot->Taille_APRES      = (int)(escargot->Taille_AVANT * ((0.4*(float)fruit->Taille_AVANT/escargot->Taille_AVANT) + (0.3*(float)racine->Taille_AVANT /escargot->Taille_AVANT)+ (0.3*(float)champignon->Taille_AVANT /escargot->Taille_AVANT)));

    larves->Taille_APRES        = (int)(larves->Taille_AVANT * ((0.4*(float)feuille->Taille_AVANT/larves->Taille_AVANT) + (0.3*(float)champignon->Taille_AVANT /larves->Taille_AVANT)+ (0.3*(float)herbe->Taille_AVANT /larves->Taille_AVANT)));

    verre_de_terre->Taille_APRES= (int)(verre_de_terre->Taille_AVANT * ((0.4*(float)racine->Taille_AVANT/verre_de_terre->Taille_AVANT) + (0.6*(float)fruit->Taille_AVANT /verre_de_terre->Taille_AVANT)));

    champignon->Taille_APRES    = (int)(champignon->Taille_AVANT * ((0.5*(float)feuille->Taille_AVANT/champignon->Taille_AVANT) + (0.5*(float)herbe->Taille_AVANT /champignon->Taille_AVANT)));

// *********************************************************************************************************************

    float EVOLUTION_OURS          = ((float)(ours->Taille_APRES          - ours->Taille_AVANT)/ours->Taille_AVANT)*100;
    float EVOLUTION_LOUP          = ((float)(loup->Taille_APRES          - loup->Taille_AVANT)/loup->Taille_AVANT)*100;
    float EVOLUTION_LYNX          = ((float)(lynx->Taille_APRES          - lynx->Taille_AVANT)/lynx->Taille_AVANT)*100;
    float EVOLUTION_AIGLE         = ((float)(aigle->Taille_APRES         - aigle->Taille_AVANT)/aigle->Taille_AVANT)*100;
    float EVOLUTION_CERF          = ((float)(cerf->Taille_APRES          - cerf->Taille_AVANT)/cerf->Taille_AVANT)*100;
    float EVOLUTION_SANGLIER      = ((float)(sanglier->Taille_APRES      - sanglier->Taille_AVANT)/sanglier->Taille_AVANT)*100;
    float EVOLUTION_FAUCON        = ((float)(faucon->Taille_APRES        - faucon->Taille_AVANT)/faucon->Taille_AVANT)*100;
    float EVOLUTION_CHEUVREUIL    = ((float)(chevreuil->Taille_APRES     - chevreuil->Taille_AVANT)/chevreuil->Taille_AVANT)*100;
    float EVOLUTION_SERPENT       = ((float)(serpent->Taille_APRES       - serpent->Taille_AVANT)/serpent->Taille_AVANT)*100;
    float EVOLUTION_BLAIREAU      = ((float)(blaireau->Taille_APRES      - blaireau->Taille_AVANT)/blaireau->Taille_AVANT)*100;
    float EVOLUTION_RENARD        = ((float)(renard->Taille_APRES        - renard->Taille_AVANT)/renard->Taille_AVANT)*100;
    float EVOLUTION_CHAUVE_SOURIS = ((float)(chauve_souris->Taille_APRES - chauve_souris->Taille_AVANT)/chauve_souris->Taille_AVANT)*100;
    float EVOLUTION_HERISSON      = ((float)(herisson->Taille_APRES      - herisson->Taille_AVANT)/herisson->Taille_AVANT)*100;
    float EVOLUTION_LAPIN         = ((float)(lapin->Taille_APRES         - lapin->Taille_AVANT)/lapin->Taille_AVANT)*100;
    float EVOLUTION_RONGEUR       = ((float)(rongeur->Taille_APRES       - rongeur->Taille_AVANT)/rongeur->Taille_AVANT)*100;
    float EVOLUTION_ECUREUIL      = ((float)(ecureuil->Taille_APRES      - ecureuil->Taille_AVANT)/ecureuil->Taille_AVANT)*100;
    float EVOLUTION_OISEAU        = ((float)(oiseau->Taille_APRES        - oiseau->Taille_AVANT)/oiseau->Taille_AVANT)*100;
    float EVOLUTION_GRENOUILLE    = ((float)(grenouille->Taille_APRES    - grenouille->Taille_AVANT)/grenouille->Taille_AVANT)*100;
    float EVOLUTION_ESCARGOT      = ((float)(escargot->Taille_APRES      - escargot->Taille_AVANT)/escargot->Taille_AVANT)*100;
    float EVOLUTION_LARVES        = ((float)(larves->Taille_APRES        - larves->Taille_AVANT)/larves->Taille_AVANT)*100;
    float EVOLUTION_INSECTES      = ((float)(insectes->Taille_APRES      - insectes->Taille_AVANT)/insectes->Taille_AVANT)*100;
    float EVOLUTION_FOURMIS       = ((float)(fourmis->Taille_APRES       - fourmis->Taille_AVANT)/fourmis->Taille_AVANT)*100;
    float EVOLUTION_VERRE_DE_TERRE= ((float)(verre_de_terre->Taille_APRES- verre_de_terre->Taille_AVANT)/verre_de_terre->Taille_AVANT)*100;
    float EVOLUTION_CHAMPIGNON    = ((float)(champignon->Taille_APRES    - champignon->Taille_AVANT)/champignon->Taille_AVANT)*100;
    float EVOLUTION_RACINE        = ((float)(racine->Taille_APRES        - racine->Taille_AVANT)/racine->Taille_AVANT)*100;
    float EVOLUTION_FRUIT         = ((float)(fruit->Taille_APRES         - fruit->Taille_AVANT)/fruit->Taille_AVANT)*100;
    float EVOLUTION_GRAINE        = ((float)(graine->Taille_APRES        - graine->Taille_AVANT)/graine->Taille_AVANT)*100;
    float EVOLUTION_HERBE         = ((float)(herbe->Taille_APRES         - herbe->Taille_AVANT)/herbe->Taille_AVANT)*100;
    float EVOLUTION_FEUILLE       = ((float)(feuille->Taille_APRES       - feuille->Taille_AVANT)/feuille->Taille_AVANT)*100;

    printf("=> OURS                : %d (%.2f %%)\n",ours->Taille_APRES, EVOLUTION_OURS);
    printf("=> LOUP                : %d (%.2f %%)\n",loup->Taille_APRES, EVOLUTION_LOUP);
    printf("=> LYNX                : %d (%.2f %%)\n",lynx->Taille_APRES, EVOLUTION_LYNX);
    printf("=> AIGLE               : %d (%.2f %%)\n",aigle->Taille_APRES, EVOLUTION_AIGLE);
    printf("=> CERF                : %d (%.2f %%)\n",cerf->Taille_APRES, EVOLUTION_CERF);
    printf("=> SANGLIER            : %d (%.2f %%)\n",sanglier->Taille_APRES, EVOLUTION_SANGLIER);
    printf("=> FAUCON              : %d (%.2f %%)\n",faucon->Taille_APRES, EVOLUTION_FAUCON);
    printf("=> CHEUVREUIL          : %d (%.2f %%)\n",chevreuil->Taille_APRES, EVOLUTION_CHEUVREUIL);
    printf("=> SERPENT             : %d (%.2f %%)\n",serpent->Taille_APRES, EVOLUTION_SERPENT);
    printf("=> BLAIREAU            : %d (%.2f %%)\n",blaireau->Taille_APRES, EVOLUTION_BLAIREAU);
    printf("=> RENARD              : %d (%.2f %%)\n",renard->Taille_APRES, EVOLUTION_RENARD);
    printf("=> CHAUVE_SOURIS       : %d (%.2f %%)\n",chauve_souris->Taille_APRES, EVOLUTION_CHAUVE_SOURIS);
    printf("=> HERISSON            : %d (%.2f %%)\n",herisson->Taille_APRES, EVOLUTION_HERISSON);
    printf("=> LAPIN               : %d (%.2f %%)\n",lapin->Taille_APRES, EVOLUTION_LAPIN);
    printf("=> RONGEUR             : %d (%.2f %%)\n",rongeur->Taille_APRES, EVOLUTION_RONGEUR);
    printf("=> ECUREUIL            : %d (%.2f %%)\n",ecureuil->Taille_APRES, EVOLUTION_ECUREUIL);
    printf("=> OISEAU              : %d (%.2f %%)\n",oiseau->Taille_APRES, EVOLUTION_OISEAU);
    printf("=> GRENOUILLE          : %d (%.2f %%)\n",grenouille->Taille_APRES, EVOLUTION_GRENOUILLE);
    printf("=> ESCARGOT            : %d (%.2f %%)\n",escargot->Taille_APRES, EVOLUTION_ESCARGOT);
    printf("=> LARVES              : %d (%.2f %%)\n",larves->Taille_APRES, EVOLUTION_LARVES);
    printf("=> INSECTES            : %d (%.2f %%)\n",insectes->Taille_APRES, EVOLUTION_INSECTES);
    printf("=> FOURMIS             : %d (%.2f %%)\n",fourmis->Taille_APRES, EVOLUTION_FOURMIS);
    printf("=> VERRE_DE_TERRE      : %d (%.2f %%)\n",verre_de_terre->Taille_APRES, EVOLUTION_VERRE_DE_TERRE);
    printf("=> CHAMPIGNON          : %d (%.2f %%)\n",champignon->Taille_APRES, EVOLUTION_CHAMPIGNON);
    printf("=> RACINE              : %d (%.2f %%)\n",racine->Taille_APRES, EVOLUTION_RACINE);
    printf("=> FRUIT               : %d (%.2f %%)\n",fruit->Taille_APRES, EVOLUTION_FRUIT);
    printf("=> GRAINE              : %d (%.2f %%)\n",graine->Taille_APRES, EVOLUTION_GRAINE);
    printf("=> HERBE               : %d (%.2f %%)\n",herbe->Taille_APRES, EVOLUTION_HERBE);
    printf("=> FEUILLE             : %d (%.2f %%)\n",feuille->Taille_APRES, EVOLUTION_FEUILLE);

//**********************************************************************************************************************
    printf("\n");
    printf("*******************************************************************************************************\n");
    printf("                                        FIN DE LA SIMULATION\n");
    printf("*******************************************************************************************************\n");
    printf("\n");
}
void PARAMETRES_SIMULATION_TRES(struct OURS *ours, struct LOUP *loup, struct LYNX *lynx, struct AIGLE *aigle, struct CERF *cerf, struct SANGLIER *sanglier, struct FAUCON *faucon, struct CHEUVREUIL *chevreuil, struct SERPENT *serpent, struct BLAIREAU *blaireau, struct RENARD *renard, struct CHAUVE_SOURIS *chauve_souris, struct HERISSON *herisson, struct LAPIN *lapin, struct RONGEUR *rongeur, struct ECUREUIL *ecureuil, struct OISEAU *oiseau, struct GRENOUILLE *grenouille, struct ESCARGOT *escargot, struct LARVES *larves, struct INSECTES *insectes, struct FOURMIS *fourmis, struct VERRE_DE_TERRE *verre_de_terre, struct CHAMPIGNON *champignon, struct RACINE *racine, struct FRUIT *fruit, struct GRAINE *graine, struct HERBE *herbe, struct FEUILLE *feuille)
{
    bool MODIFICATION = true;
    int choix_PARAMETRE;
    int NEW =2;

    while (MODIFICATION==true)
    {
        printf("*******************************************************************************************************\n");
        printf("                                        PARAMETRES DE LA SIMULATION\n");
        printf("*******************************************************************************************************\n");
        printf("QUEL PARAMETRE VOULEZ-VOUS MODIFIER ?\n");
        printf("1 - Ours\n");
        printf("2 - Loup\n");
        printf("3 - Lynx\n");
        printf("4 - Aigle\n");
        printf("5 - Cerf\n");
        printf("6 - Sanglier\n");
        printf("7 - Faucon\n");
        printf("8 - Chevreuil\n");
        printf("9 - Serpent\n");
        printf("10 - Blaireau\n");
        printf("11 - Renard\n");
        printf("12 - Chauve-souris\n");
        printf("13 - Herisson\n");
        printf("14 - Lapin\n");
        printf("15 - Rongeur\n");
        printf("16 - Ecureuil\n");
        printf("17 - Oiseau\n");
        printf("18 - Grenouille\n");
        printf("19 - Escargot\n");
        printf("20 - Larves\n");
        printf("21 - Insectes\n");
        printf("22 - Fourmis\n");
        printf("23 - Verre de terre\n");
        printf("24 - Champignon\n");
        printf("25 - Racine\n");
        printf("26 - Fruit\n");
        printf("27 - Graine\n");
        printf("28 - Herbe\n");
        printf("29 - Feuille\n");
        printf("0 - Quitter\n");
        printf("-------------------------------------------------------------------------------------------------------\n");
        printf("\n");

        scanf("%d", &choix_PARAMETRE);

        switch (choix_PARAMETRE)
        {
            case 1:
                printf("Ours\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &ours->Taille_AVANT);
                }while (ours->Taille_AVANT < 1 || ours->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                ours->Modifie = true;
                NEW = 2;
                break;
            case 2:
                printf("Loup\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &loup->Taille_AVANT);
                }while (loup->Taille_AVANT < 1 || loup->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                loup->Modifie = true;
                NEW = 2;
                break;
            case 3:
                printf("Lynx\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &lynx->Taille_AVANT);
                }while (lynx->Taille_AVANT < 1 || lynx->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                lynx->Modifie = true;
                NEW = 2;
                break;
            case 4:
                printf("Aigle\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &aigle->Taille_AVANT);
                }while (aigle->Taille_AVANT < 1 || aigle->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                aigle->Modifie = true;
                NEW = 2;
                break;
            case 5:
                printf("Cerf\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &cerf->Taille_AVANT);
                }while (cerf->Taille_AVANT < 1 || cerf->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                cerf->Modifie = true;
                NEW = 2;
                break;
            case 6:
                printf("Sanglier\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &sanglier->Taille_AVANT);
                }while (sanglier->Taille_AVANT < 1 || sanglier->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                sanglier->Modifie = true;
                NEW = 2;
                break;
            case 7:
                printf("Faucon\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &faucon->Taille_AVANT);
                }while (faucon->Taille_AVANT < 1 || faucon->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                faucon->Modifie = true;
                NEW = 2;
                break;
            case 8:
                printf("Chevreuil\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &chevreuil->Taille_AVANT);
                }while (chevreuil->Taille_AVANT < 1 || chevreuil->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                chevreuil->Modifie = true;
                NEW = 2;
                break;
            case 9:
                printf("Serpent\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &serpent->Taille_AVANT);
                }while (serpent->Taille_AVANT < 1 || serpent->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                serpent->Modifie = true;
                NEW = 2;
                break;
            case 10:
                printf("Blaireau\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &blaireau->Taille_AVANT);
                }while (blaireau->Taille_AVANT < 1 || blaireau->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                blaireau->Modifie = true;
                NEW = 2;
                break;
            case 11:
                printf("Renard\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &renard->Taille_AVANT);
                }while (renard->Taille_AVANT < 1 || renard->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                renard->Modifie = true;
                NEW = 2;
                break;
            case 12:
                printf("Chauve-souris\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &chauve_souris->Taille_AVANT);
                }while (chauve_souris->Taille_AVANT < 1 || chauve_souris->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                chauve_souris->Modifie = true;
                NEW = 2;
                break;
            case 13:
                printf("Herisson\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &herisson->Taille_AVANT);
                }while (herisson->Taille_AVANT < 1 || herisson->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                herisson->Modifie = true;
                NEW = 2;
                break;
            case 14:
                printf("Lapin\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &lapin->Taille_AVANT);
                }while (lapin->Taille_AVANT < 1 || lapin->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                lapin->Modifie = true;
                NEW = 2;
                break;
            case 15:
                printf("Rongeur\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &rongeur->Taille_AVANT);
                }while (rongeur->Taille_AVANT < 1 || rongeur->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                rongeur->Modifie = true;
                NEW = 2;
                break;
            case 16:
                printf("Ecureuil\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &ecureuil->Taille_AVANT);
                }while (ecureuil->Taille_AVANT < 1 || ecureuil->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                ecureuil->Modifie = true;
                NEW = 2;
                break;
            case 17:
                printf("Oiseau\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &oiseau->Taille_AVANT);
                }while (oiseau->Taille_AVANT < 1 || oiseau->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                oiseau->Modifie = true;
                NEW = 2;
                break;
            case 18:
                printf("Grenouille\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &grenouille->Taille_AVANT);
                }while (grenouille->Taille_AVANT < 1 || grenouille->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                grenouille->Modifie = true;
                NEW = 2;
                break;
            case 19:
                printf("Escargot\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &escargot->Taille_AVANT);
                }while (escargot->Taille_AVANT < 1 || escargot->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                escargot->Modifie = true;
                NEW = 2;
                break;
            case 20:
                printf("Larves\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &larves->Taille_AVANT);
                }while (larves->Taille_AVANT < 1 || larves->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                larves->Modifie = true;
                NEW = 2;
                break;
            case 21:
                printf("Insectes\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &insectes->Taille_AVANT);
                }while (insectes->Taille_AVANT < 1 || insectes->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                insectes->Modifie = true;
                NEW = 2;
                break;
            case 22:
                printf("Fourmis\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &fourmis->Taille_AVANT);
                }while (fourmis->Taille_AVANT < 1 || fourmis->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                fourmis->Modifie = true;
                NEW = 2;
                break;
            case 23:
                printf("Verre de terre\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &verre_de_terre->Taille_AVANT);
                }while (verre_de_terre->Taille_AVANT < 1 || verre_de_terre->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                verre_de_terre->Modifie = true;
                NEW = 2;
                break;
            case 24:
                printf("Champignon\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &champignon->Taille_AVANT);
                }while (champignon->Taille_AVANT < 1 || champignon->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                champignon->Modifie = true;
                NEW = 2;
                break;
            case 25:
                printf("Racine\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &racine->Taille_AVANT);
                }while (racine->Taille_AVANT < 1 || racine->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                racine->Modifie = true;
                NEW = 2;
                break;
            case 26:
                printf("Fruit\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &fruit->Taille_AVANT);
                }while (fruit->Taille_AVANT < 1 || fruit->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                fruit->Modifie = true;
                NEW = 2;
                break;
            case 27:
                printf("Graine\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &graine->Taille_AVANT);
                }while (graine->Taille_AVANT < 1 || graine->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                graine->Modifie = true;
                NEW = 2;
                break;
            case 28:
                printf("Herbe\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &herbe->Taille_AVANT);
                }while (herbe->Taille_AVANT < 1 || herbe->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                herbe->Modifie = true;
                NEW = 2;
                break;
            case 29:
                printf("Feuille\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &feuille->Taille_AVANT);
                }while (feuille->Taille_AVANT < 1 || feuille->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                feuille->Modifie = true;
                NEW = 2;
                break;
            default:
                printf("Retour Menu\n");
                MODIFICATION = false;
                break;
        }
    }
}
void RETOUR_A_NORME_TRES(struct OURS *ours, struct LOUP *loup, struct LYNX *lynx, struct AIGLE *aigle, struct CERF *cerf, struct SANGLIER *sanglier, struct FAUCON *faucon, struct CHEUVREUIL *chevreuil, struct SERPENT *serpent, struct BLAIREAU *blaireau, struct RENARD *renard, struct CHAUVE_SOURIS *chauve_souris, struct HERISSON *herisson, struct LAPIN *lapin, struct RONGEUR *rongeur, struct ECUREUIL *ecureuil, struct OISEAU *oiseau, struct GRENOUILLE *grenouille, struct ESCARGOT *escargot, struct LARVES *larves, struct INSECTES *insectes, struct FOURMIS *fourmis, struct VERRE_DE_TERRE *verre_de_terre, struct CHAMPIGNON *champignon, struct RACINE *racine, struct FRUIT *fruit, struct GRAINE *graine, struct HERBE *herbe, struct FEUILLE *feuille)
{
    if (ours->Modifie == true)
    {
        ours->Taille_AVANT = 100;
    }
    if (loup->Modifie == true)
    {
        loup->Taille_AVANT = 100;
    }
    if (lynx->Modifie == true)
    {
        lynx->Taille_AVANT = 100;
    }
    if (aigle->Modifie == true)
    {
        aigle->Taille_AVANT = 100;
    }
    if (cerf->Modifie == true)
    {
        cerf->Taille_AVANT = 100;
    }
    if (sanglier->Modifie == true)
    {
        sanglier->Taille_AVANT = 100;
    }
    if (faucon->Modifie == true)
    {
        faucon->Taille_AVANT = 100;
    }
    if (chevreuil->Modifie == true)
    {
        chevreuil->Taille_AVANT = 100;
    }
    if (serpent->Modifie == true)
    {
        serpent->Taille_AVANT = 100;
    }
    if (blaireau->Modifie == true)
    {
        blaireau->Taille_AVANT = 100;
    }
    if (renard->Modifie == true)
    {
        renard->Taille_AVANT = 100;
    }
    if (chauve_souris->Modifie == true)
    {
        chauve_souris->Taille_AVANT = 100;
    }
    if (herisson->Modifie == true)
    {
        herisson->Taille_AVANT = 100;
    }
    if (lapin->Modifie == true)
    {
        lapin->Taille_AVANT = 100;
    }
    if (rongeur->Modifie == true)
    {
        rongeur->Taille_AVANT = 100;
    }
    if (ecureuil->Modifie == true)
    {
        ecureuil->Taille_AVANT = 100;
    }
    if (oiseau->Modifie == true)
    {
        oiseau->Taille_AVANT = 100;
    }
    if (grenouille->Modifie == true)
    {
        grenouille->Taille_AVANT = 100;
    }
    if (escargot->Modifie == true)
    {
        escargot->Taille_AVANT = 100;
    }
    if (larves->Modifie == true)
    {
        larves->Taille_AVANT = 100;
    }
    if (insectes->Modifie == true)
    {
        insectes->Taille_AVANT = 100;
    }
    if (fourmis->Modifie == true)
    {
        fourmis->Taille_AVANT = 100;
    }
    if (verre_de_terre->Modifie == true)
    {
        verre_de_terre->Taille_AVANT = 100;
    }
    if (champignon->Modifie == true)
    {
        champignon->Taille_AVANT = 100;
    }
    if (racine->Modifie == true)
    {
        racine->Taille_AVANT = 100;
    }
    if (fruit->Modifie == true)
    {
        fruit->Taille_AVANT = 100;
    }
    if (graine->Modifie == true)
    {
        graine->Taille_AVANT = 100;
    }
    if (herbe->Modifie == true)
    {
        herbe->Taille_AVANT = 100;
    }
    if (feuille->Modifie == true)
    {
        feuille->Taille_AVANT = 100;
    }

};