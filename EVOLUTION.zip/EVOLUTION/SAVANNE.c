#include "BIBLIO.h"


void SIMULATION_DOS(struct VAUTOUR * vautour, struct LION * lion, struct GUEPARD * guepard, struct HYENE * hyene, struct CHACAL * chacal, struct MANGOUSTE * mangouste, struct SERPENT_SAVANE * serpent_savane, struct OISEAU_SAVANE * oiseau_savane, struct PHACOCHERE * phacochere, struct GAZELLE * gazelle, struct ZEBRE * zebre, struct ANTILOPE * antilope, struct TERMITE * termite, struct INSECTE_SAVANE * insecte_savane, struct RACINE_SAVANE * racine_savane, struct FRUIT_SAVANE * fruit_savane, struct HERBE_SAVANE * herbe_savane, struct BUISSON * buisson)
{
    printf("\n");
    printf("*******************************************************************************************************\n");
    printf("                                        DEBUT DE LA SIMULATION\n");
    printf("*******************************************************************************************************\n");
    printf("-------------------------------------------------------------------------------------------------------\n");
    printf("AVANT\n");
    printf("-------------------------------------------------------------------------------------------------------\n");
    printf("=> VAUTOUR             : %d\n", vautour->Taille_AVANT);
    printf("=> LION                : %d\n", lion->Taille_AVANT);
    printf("=> GUEPARD             : %d\n", guepard->Taille_AVANT);
    printf("=> HYENE               : %d\n", hyene->Taille_AVANT);
    printf("=> CHACAL              : %d\n", chacal->Taille_AVANT);
    printf("=> MANGOUSTE           : %d\n", mangouste->Taille_AVANT);
    printf("=> SERPENT             : %d\n", serpent_savane->Taille_AVANT);
    printf("=> OISEAU              : %d\n", oiseau_savane->Taille_AVANT);
    printf("=> PHACOCHERE          : %d\n", phacochere->Taille_AVANT);
    printf("=> GAZELLE             : %d\n", gazelle->Taille_AVANT);
    printf("=> ZEBRE               : %d\n", zebre->Taille_AVANT);
    printf("=> ANTILOPE            : %d\n", antilope->Taille_AVANT);
    printf("=> TERMITE             : %d\n", termite->Taille_AVANT);
    printf("=> INSECTE             : %d\n", insecte_savane->Taille_AVANT);
    printf("=> RACINE              : %d\n", racine_savane->Taille_AVANT);
    printf("=> FRUIT               : %d\n", fruit_savane->Taille_AVANT);
    printf("=> BUISSON             : %d\n", buisson->Taille_AVANT);
    printf("=> HERBE               : %d\n", herbe_savane->Taille_AVANT);
    printf("-------------------------------------------------------------------------------------------------------\n");
    printf("APRES\n");
    printf("-------------------------------------------------------------------------------------------------------\n");

//**********************************************************************************************************************

    vautour->Taille_APRES        = vautour->Taille_AVANT;
    lion->Taille_APRES           = lion->Taille_AVANT;
    guepard->Taille_APRES        = guepard->Taille_AVANT;
    hyene->Taille_APRES          = hyene->Taille_AVANT;
    chacal->Taille_APRES         = chacal->Taille_AVANT;
    mangouste->Taille_APRES      = mangouste->Taille_AVANT;
    serpent_savane->Taille_APRES = serpent_savane->Taille_AVANT;
    oiseau_savane->Taille_APRES  = oiseau_savane->Taille_AVANT;
    phacochere->Taille_APRES     = phacochere->Taille_AVANT;
    gazelle->Taille_APRES        = gazelle->Taille_AVANT;
    zebre->Taille_APRES          = zebre->Taille_AVANT;
    antilope->Taille_APRES       = antilope->Taille_AVANT;
    termite->Taille_APRES        = termite->Taille_AVANT;
    insecte_savane->Taille_APRES = insecte_savane->Taille_AVANT;
    racine_savane->Taille_APRES  = racine_savane->Taille_AVANT;
    fruit_savane->Taille_APRES   = fruit_savane->Taille_AVANT;
    buisson->Taille_APRES        = buisson->Taille_AVANT;
    herbe_savane->Taille_APRES   = herbe_savane->Taille_AVANT;

//**********************************************************************************************************************

    vautour->Taille_APRES          = (int)(vautour->Taille_AVANT * ((0.2*(float)oiseau_savane->Taille_AVANT/vautour->Taille_AVANT) + (0.1*(float)hyene->Taille_AVANT /vautour->Taille_AVANT) + (0.1*(float)chacal->Taille_AVANT/vautour->Taille_AVANT) + (0.3*(float)lion->Taille_AVANT /vautour->Taille_AVANT) + (0.3*(float)guepard->Taille_AVANT /vautour->Taille_AVANT) ));

    lion->Taille_APRES             = (int)(lion->Taille_AVANT * ((0.2*(float)gazelle->Taille_AVANT/lion->Taille_AVANT) + (0.2*(float)antilope->Taille_AVANT /lion->Taille_AVANT) + (0.2*(float)zebre->Taille_AVANT/lion->Taille_AVANT) + (0.1*(float)hyene->Taille_AVANT /lion->Taille_AVANT) + (0.1*(float)chacal->Taille_AVANT /lion->Taille_AVANT) + (0.2*(float)phacochere->Taille_AVANT /lion->Taille_AVANT)));

    guepard->Taille_APRES          = (int)(guepard->Taille_AVANT * ((0.3*(float)gazelle->Taille_AVANT/guepard->Taille_AVANT) + (0.3*(float)antilope->Taille_AVANT /guepard->Taille_AVANT) + (0.2*(float)zebre->Taille_AVANT/guepard->Taille_AVANT) + (0.2*(float)phacochere->Taille_AVANT /guepard->Taille_AVANT)));

    hyene->Taille_APRES            = (int)(hyene->Taille_AVANT * ((0.3*(float)gazelle->Taille_AVANT/hyene->Taille_AVANT) + (0.3*(float)antilope->Taille_AVANT /hyene->Taille_AVANT) + (0.2*(float)zebre->Taille_AVANT/hyene->Taille_AVANT) + (0.1*(float)serpent_savane->Taille_AVANT /hyene->Taille_AVANT) + (0.1*(float)oiseau_savane->Taille_AVANT /hyene->Taille_AVANT)));

    chacal->Taille_APRES           = (int)(chacal->Taille_AVANT * ((0.4*(float)gazelle->Taille_AVANT/chacal->Taille_AVANT) + (0.4*(float)phacochere->Taille_AVANT /chacal->Taille_AVANT) + (0.2*(float)serpent_savane->Taille_AVANT/chacal->Taille_AVANT) ));

    mangouste->Taille_APRES        = (int)(mangouste->Taille_AVANT * ((0.4*(float)serpent_savane->Taille_AVANT/mangouste->Taille_AVANT) + (0.1*(float)oiseau_savane->Taille_AVANT /mangouste->Taille_AVANT) + (0.2*(float)termite->Taille_AVANT/mangouste->Taille_AVANT) + (0.3*(float)insecte_savane->Taille_AVANT/mangouste->Taille_AVANT)));

    serpent_savane->Taille_APRES   = (int)(serpent_savane->Taille_AVANT * (float)oiseau_savane->Taille_AVANT / serpent_savane->Taille_AVANT);

    oiseau_savane->Taille_APRES    = (int)(oiseau_savane->Taille_AVANT * ((0.9*(float)insecte_savane->Taille_AVANT/oiseau_savane->Taille_AVANT) + (0.1*(float)termite->Taille_AVANT /oiseau_savane->Taille_AVANT)));

    phacochere->Taille_APRES       = (int)(phacochere->Taille_AVANT * ((0.3*(float)racine_savane->Taille_AVANT/phacochere->Taille_AVANT) + (0.3*(float)fruit_savane->Taille_AVANT /phacochere->Taille_AVANT) + (0.4*(float)buisson->Taille_AVANT/phacochere->Taille_AVANT)));

    gazelle->Taille_APRES          = (int)(gazelle->Taille_AVANT * ((0.6*(float)herbe_savane->Taille_AVANT/gazelle->Taille_AVANT) + (0.4*(float)buisson->Taille_AVANT /gazelle->Taille_AVANT) ));

    zebre->Taille_APRES            = (int)(zebre->Taille_AVANT * ((0.5*(float)herbe_savane->Taille_AVANT/zebre->Taille_AVANT) + (0.5*(float)fruit_savane->Taille_AVANT /zebre->Taille_AVANT) ));

    antilope->Taille_APRES         = (int)(antilope->Taille_AVANT * ((0.6*(float)herbe_savane->Taille_AVANT/antilope->Taille_AVANT) + (0.2*(float)buisson->Taille_AVANT /antilope->Taille_AVANT) + (0.2*(float)fruit_savane->Taille_AVANT /antilope->Taille_AVANT) ));

    insecte_savane->Taille_APRES   = (int)(insecte_savane->Taille_AVANT * ((0.2*(float)racine_savane->Taille_AVANT/insecte_savane->Taille_AVANT) + (0.5*(float)fruit_savane->Taille_AVANT /insecte_savane->Taille_AVANT) + (0.3*(float)herbe_savane->Taille_AVANT /insecte_savane->Taille_AVANT)));

// *********************************************************************************************************************

    float EVOLUTION_VAUTOUR         = ((float)(vautour->Taille_APRES          - vautour->Taille_AVANT)/vautour->Taille_AVANT)*100;
    float EVOLUTION_LION            = ((float)(lion->Taille_APRES             - lion->Taille_AVANT)/lion->Taille_AVANT)*100;
    float EVOLUTION_GUEPARD         = ((float)(guepard->Taille_APRES          - guepard->Taille_AVANT)/guepard->Taille_AVANT)*100;
    float EVOLUTION_HYENE           = ((float)(hyene->Taille_APRES            - hyene->Taille_AVANT)/hyene->Taille_AVANT)*100;
    float EVOLUTION_CHACAL          = ((float)(chacal->Taille_APRES           - chacal->Taille_AVANT)/chacal->Taille_AVANT)*100;
    float EVOLUTION_MANGOUSTE       = ((float)(mangouste->Taille_APRES        - mangouste->Taille_AVANT)/mangouste->Taille_AVANT)*100;
    float EVOLUTION_SERPENT         = ((float)(serpent_savane->Taille_APRES   - serpent_savane->Taille_AVANT)/serpent_savane->Taille_AVANT)*100;
    float EVOLUTION_OISEAU          = ((float)(oiseau_savane->Taille_APRES    - oiseau_savane->Taille_AVANT)/oiseau_savane->Taille_AVANT)*100;
    float EVOLUTION_PHACOCHERE      = ((float)(phacochere->Taille_APRES       - phacochere->Taille_AVANT)/phacochere->Taille_AVANT)*100;
    float EVOLUTION_GAZELLE         = ((float)(gazelle->Taille_APRES          - gazelle->Taille_AVANT)/gazelle->Taille_AVANT)*100;
    float EVOLUTION_ZEBRE           = ((float)(zebre->Taille_APRES            - zebre->Taille_AVANT)/zebre->Taille_AVANT)*100;
    float EVOLUTION_ANTILOPE        = ((float)(antilope->Taille_APRES         - antilope->Taille_AVANT)/antilope->Taille_AVANT)*100;
    float EVOLUTION_TERMITE         = ((float)(termite->Taille_APRES          - termite->Taille_AVANT)/termite->Taille_AVANT)*100;
    float EVOLUTION_INSECTE         = ((float)(insecte_savane->Taille_APRES   - insecte_savane->Taille_AVANT)/insecte_savane->Taille_AVANT)*100;
    float EVOLUTION_RACINE          = ((float)(racine_savane->Taille_APRES    - racine_savane->Taille_AVANT)/racine_savane->Taille_AVANT)*100;
    float EVOLUTION_FRUIT           = ((float)(fruit_savane->Taille_APRES     - fruit_savane->Taille_AVANT)/fruit_savane->Taille_AVANT)*100;
    float EVOLUTION_BUISSON         = ((float)(buisson->Taille_APRES          - buisson->Taille_AVANT)/buisson->Taille_AVANT)*100;
    float EVOLUTION_HERBE           = ((float)(herbe_savane->Taille_APRES     - herbe_savane->Taille_AVANT)/herbe_savane->Taille_AVANT)*100;

    printf("=> VAUTOUR      : %d (%.2f %%)\n",vautour->Taille_APRES, EVOLUTION_VAUTOUR);
    printf("=> LION         : %d (%.2f %%)\n",lion->Taille_APRES, EVOLUTION_LION);
    printf("=> GUEPARD      : %d (%.2f %%)\n",guepard->Taille_APRES, EVOLUTION_GUEPARD);
    printf("=> HYENE        : %d (%.2f %%)\n",hyene->Taille_APRES, EVOLUTION_HYENE);
    printf("=> CHACAL       : %d (%.2f %%)\n",chacal->Taille_APRES, EVOLUTION_CHACAL);
    printf("=> MANGOUSTE    : %d (%.2f %%)\n",mangouste->Taille_APRES, EVOLUTION_MANGOUSTE);
    printf("=> SERPENT      : %d (%.2f %%)\n",serpent_savane->Taille_APRES, EVOLUTION_SERPENT);
    printf("=> OISEAU       : %d (%.2f %%)\n",oiseau_savane->Taille_APRES, EVOLUTION_OISEAU);
    printf("=> PHACOCHERE   : %d (%.2f %%)\n",phacochere->Taille_APRES, EVOLUTION_PHACOCHERE);
    printf("=> GAZELLE      : %d (%.2f %%)\n",gazelle->Taille_APRES, EVOLUTION_GAZELLE);
    printf("=> ZEBRE        : %d (%.2f %%)\n",zebre->Taille_APRES, EVOLUTION_ZEBRE);
    printf("=> ANTILOPE     : %d (%.2f %%)\n",antilope->Taille_APRES, EVOLUTION_ANTILOPE);
    printf("=> TERMITE      : %d (%.2f %%)\n",termite->Taille_APRES, EVOLUTION_TERMITE);
    printf("=> INSECTE      : %d (%.2f %%)\n",insecte_savane->Taille_APRES, EVOLUTION_INSECTE);
    printf("=> RACINE       : %d (%.2f %%)\n",racine_savane->Taille_APRES, EVOLUTION_RACINE);
    printf("=> FRUIT        : %d (%.2f %%)\n",fruit_savane->Taille_APRES, EVOLUTION_FRUIT);
    printf("=> BUISSON      : %d (%.2f %%)\n",buisson->Taille_APRES, EVOLUTION_BUISSON);
    printf("=> HERBE        : %d (%.2f %%)\n",herbe_savane->Taille_APRES, EVOLUTION_HERBE);

//**********************************************************************************************************************
    printf("\n");
    printf("*******************************************************************************************************\n");
    printf("                                        FIN DE LA SIMULATION\n");
    printf("*******************************************************************************************************\n");
    printf("\n");
}
void PARAMETRES_SIMULATION_DOS(struct VAUTOUR * vautour, struct LION * lion, struct GUEPARD * guepard, struct HYENE * hyene, struct CHACAL * chacal, struct MANGOUSTE * mangouste, struct SERPENT_SAVANE * serpent_savane, struct OISEAU_SAVANE * oiseau_savane, struct PHACOCHERE * phacochere, struct GAZELLE * gazelle, struct ZEBRE * zebre, struct ANTILOPE * antilope, struct TERMITE * termite, struct INSECTE_SAVANE * insecte_savane, struct RACINE_SAVANE * racine_savane, struct FRUIT_SAVANE * fruit_savane, struct HERBE_SAVANE * herbe_savane, struct BUISSON * buisson)
{
    bool MODIFICATION = true;
    int choix_PARAMETRE;
    int NEW =2;

    while (MODIFICATION==true)
    {
        printf("*******************************************************************************************************\n");
        printf("                                        PARAMETRES DE LA SIMULATION\n");
        printf("*******************************************************************************************************\n");
        printf("QUEL PARAMETRE VOULEZ-VOUS MODIFIER ?\n");
        printf("1  - VAUTOUR\n");
        printf("2  - LION\n");
        printf("3  - GUEPARD\n");
        printf("4  - HYENE\n");
        printf("5  - CHACAL\n");
        printf("6  - MANGOUSTE\n");
        printf("7  - SERPENT\n");
        printf("8  - OISEAU\n");
        printf("9  - PHACOCHERE\n");
        printf("10 - GAZELLE\n");
        printf("11 - ZEBRE\n");
        printf("12 - ANTILOPE\n");
        printf("13 - TERMITE\n");
        printf("14 - INSECTE\n");
        printf("15 - RACINE\n");
        printf("16 - FRUIT\n");
        printf("17 - BUISSON\n");
        printf("18 - HERBE\n");
        printf("0 - Quitter\n");
        printf("-------------------------------------------------------------------------------------------------------\n");
        printf("\n");

        scanf("%d", &choix_PARAMETRE);

        switch (choix_PARAMETRE)
        {
            case 1:
                printf("Vautour\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &vautour->Taille_AVANT);
                }while (vautour->Taille_AVANT < 1 || vautour->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                vautour->Modifie = true;
                NEW = 2;
                break;
            case 2:
                printf("Lion\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &lion->Taille_AVANT);
                }while (lion->Taille_AVANT < 1 || lion->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                lion->Modifie = true;
                NEW = 2;
                break;
            case 3:
                printf("Guepard\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &guepard->Taille_AVANT);
                }while (guepard->Taille_AVANT < 1 || guepard->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                guepard->Modifie = true;
                NEW = 2;
                break;
            case 4:
                printf("Hyene\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &hyene->Taille_AVANT);
                }while (hyene->Taille_AVANT < 1 || hyene->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                hyene->Modifie = true;
                NEW = 2;
                break;
            case 5:
                printf("Chacal\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &chacal->Taille_AVANT);
                }while (chacal->Taille_AVANT < 1 || chacal->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                chacal->Modifie = true;
                NEW = 2;
                break;
            case 6:
                printf("Mangouste\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &mangouste->Taille_AVANT);
                }while (mangouste->Taille_AVANT < 1 || mangouste->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                mangouste->Modifie = true;
                NEW = 2;
                break;
            case 7:
                printf("Serpent\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &serpent_savane->Taille_AVANT);
                }while (serpent_savane->Taille_AVANT < 1 || serpent_savane->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                serpent_savane->Modifie = true;
                NEW = 2;
                break;
            case 8:
                printf("Oiseaux\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &oiseau_savane->Taille_AVANT);
                }while (oiseau_savane->Taille_AVANT < 1 || oiseau_savane->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                oiseau_savane->Modifie = true;
                NEW = 2;
                break;
            case 9:
                printf("Phacochere\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &phacochere->Taille_AVANT);
                }while (phacochere->Taille_AVANT < 1 || phacochere->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                phacochere->Modifie = true;
                NEW = 2;
                break;
            case 10:
                printf("Gazelle\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &gazelle->Taille_AVANT);
                }while (gazelle->Taille_AVANT < 1 || gazelle->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                gazelle->Modifie = true;
                NEW = 2;
                break;
            case 11:
                printf("Zebre\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &zebre->Taille_AVANT);
                }while (zebre->Taille_AVANT < 1 || zebre->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                zebre->Modifie = true;
                NEW = 2;
                break;
            case 12:
                printf("Antilope\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &antilope->Taille_AVANT);
                }while (antilope->Taille_AVANT < 1 || antilope->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                antilope->Modifie = true;
                NEW = 2;
                break;
            case 13:
                printf("Termite\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &termite->Taille_AVANT);
                }while (termite->Taille_AVANT < 1 || termite->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                termite->Modifie = true;
                NEW = 2;
                break;
            case 14:
                printf("Insecte\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &insecte_savane->Taille_AVANT);
                }while (insecte_savane->Taille_AVANT < 1 || insecte_savane->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                insecte_savane->Modifie = true;
                NEW = 2;
                break;
            case 15:
                printf("Racine\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &racine_savane->Taille_AVANT);
                }while (racine_savane->Taille_AVANT < 1 || racine_savane->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW != 0 && NEW != 1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                racine_savane->Modifie = true;
                NEW = 2;
                break;
            case 16:
                printf("Fruit\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &fruit_savane->Taille_AVANT);
                }while (fruit_savane->Taille_AVANT < 1 || fruit_savane->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                } while (NEW != 0 && NEW != 1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                fruit_savane->Modifie = true;
                NEW = 2;
                break;
            case 17:
                printf("Buisson\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &buisson->Taille_AVANT);
                }while (buisson->Taille_AVANT < 1 || buisson->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                } while (NEW != 0 && NEW != 1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                buisson->Modifie = true;
                NEW = 2;
                break;
            case 18:
                printf("Herbe\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &herbe_savane->Taille_AVANT);
                }while (herbe_savane->Taille_AVANT < 1 || herbe_savane->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                } while (NEW != 0 && NEW != 1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                herbe_savane->Modifie = true;
                NEW = 2;
                break;
            default:
                printf("Retour Menu\n");
                MODIFICATION = false;
                break;
        }
    }
}
void RETOUR_A_NORME_DOS(struct VAUTOUR * vautour, struct LION * lion, struct GUEPARD * guepard, struct HYENE * hyene, struct CHACAL * chacal, struct MANGOUSTE * mangouste, struct SERPENT_SAVANE * serpent_savane, struct OISEAU_SAVANE * oiseau_savane, struct PHACOCHERE * phacochere, struct GAZELLE * gazelle, struct ZEBRE * zebre, struct ANTILOPE * antilope, struct TERMITE * termite, struct INSECTE_SAVANE * insecte_savane, struct RACINE_SAVANE * racine_savane, struct FRUIT_SAVANE * fruit_savane, struct HERBE_SAVANE * herbe_savane, struct BUISSON * buisson)
{
    if (vautour->Modifie == true)
    {
        vautour->Taille_AVANT = 100;
    }
    if (lion->Modifie == true)
    {
        lion->Taille_AVANT = 100;
    }
    if (guepard->Modifie == true)
    {
        guepard->Taille_AVANT = 100;
    }
    if (hyene->Modifie == true)
    {
        hyene->Taille_AVANT = 100;
    }
    if (chacal->Modifie == true)
    {
        chacal->Taille_AVANT = 100;
    }
    if (mangouste->Modifie == true)
    {
        mangouste->Taille_AVANT = 100;
    }
    if (serpent_savane->Modifie == true)
    {
        serpent_savane->Taille_AVANT = 100;
    }
    if (oiseau_savane->Modifie == true)
    {
        oiseau_savane->Taille_AVANT = 100;
    }
    if (phacochere->Modifie == true)
    {
        phacochere->Taille_AVANT = 100;
    }
    if (gazelle->Modifie == true)
    {
        gazelle->Taille_AVANT = 100;
    }
    if (zebre->Modifie == true)
    {
        zebre->Taille_AVANT = 100;
    }
    if (antilope->Modifie == true)
    {
        antilope->Taille_AVANT = 100;
    }
    if (termite->Modifie == true)
    {
        termite->Taille_AVANT = 100;
    }
    if (insecte_savane->Modifie == true)
    {
        insecte_savane->Taille_AVANT = 100;
    }
    if (racine_savane->Modifie == true)
    {
        racine_savane->Taille_AVANT = 100;
    }
    if (fruit_savane->Modifie == true)
    {
        fruit_savane->Taille_AVANT = 100;
    }
    if (buisson->Modifie == true)
    {
        buisson->Taille_AVANT = 100;
    }
    if (herbe_savane->Modifie == true)
    {
        herbe_savane->Taille_AVANT = 100;
    }
}