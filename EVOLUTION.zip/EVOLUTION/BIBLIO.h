//
// Created by Victor on 08/12/2024.
//

#ifndef EVOLUTION_BIBLIO_H
#define EVOLUTION_BIBLIO_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>

struct OURS {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct LOUP {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct LYNX {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct AIGLE {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct CERF {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct SANGLIER {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct FAUCON {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct CHEUVREUIL {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct SERPENT {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct BLAIREAU {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct RENARD {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct CHAUVE_SOURIS {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct HERISSON {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct LAPIN {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct RONGEUR {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct ECUREUIL {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct OISEAU {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct GRENOUILLE {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct ESCARGOT {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct LARVES {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct INSECTES {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct FOURMIS {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct VERRE_DE_TERRE {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct CHAMPIGNON {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct RACINE {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct FRUIT {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct GRAINE {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct HERBE {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct FEUILLE {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};

//**********************************************************************************************************************

struct VAUTOUR {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct LION {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct GUEPARD {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct HYENE {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct CHACAL {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct MANGOUSTE {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct SERPENT_SAVANE {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct OISEAU_SAVANE {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct PHACOCHERE {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct GAZELLE {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct ZEBRE {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct ANTILOPE {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct TERMITE {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct INSECTE_SAVANE {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct RACINE_SAVANE {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct FRUIT_SAVANE {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct BUISSON {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct HERBE_SAVANE {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
//**********************************************************************************************************************

struct ORQUE {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct LEOPARD_DE_MER {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct MANCHOT_EMPEREUR {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct ELEPHANT_DE_MER {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct PHOQUE {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct BALEINE_A_BOSSE {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct GROS_POISSONS {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct PETITS_POISSONS {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
struct KRILL {
    int Taille_AVANT;
    bool Modifie;
    int Taille_APRES;
};
//**********************************************************************************************************************

void SIMULATION_UNO(struct ORQUE *orque, struct LEOPARD_DE_MER *leopard_de_mer, struct MANCHOT_EMPEREUR *manchot_empereur, struct ELEPHANT_DE_MER *elephant_de_mer, struct PHOQUE *phoque, struct BALEINE_A_BOSSE *baleine_a_bosse, struct GROS_POISSONS *gros_poissons, struct PETITS_POISSONS *petits_poissons, struct KRILL *krill);
void PARAMETRES_SIMULATION_UNO(struct ORQUE *orque, struct LEOPARD_DE_MER *leopard_de_mer, struct MANCHOT_EMPEREUR *manchot_empereur, struct ELEPHANT_DE_MER *elephant_de_mer, struct PHOQUE *phoque, struct BALEINE_A_BOSSE *baleine_a_bosse, struct GROS_POISSONS *gros_poissons, struct PETITS_POISSONS *petits_poissons, struct KRILL *krill);
void RETOUR_A_NORME_UNO(struct ORQUE *orque, struct LEOPARD_DE_MER *leopard_de_mer, struct MANCHOT_EMPEREUR *manchot_empereur, struct ELEPHANT_DE_MER *elephant_de_mer, struct PHOQUE *phoque, struct BALEINE_A_BOSSE *baleine_a_bosse, struct GROS_POISSONS *gros_poissons, struct PETITS_POISSONS *petits_poissons, struct KRILL *krill);

void SIMULATION_DOS(struct VAUTOUR * vautour, struct LION * lion, struct GUEPARD * guepard, struct HYENE * hyene, struct CHACAL * chacal, struct MANGOUSTE * mangouste, struct SERPENT_SAVANE * serpent_savane, struct OISEAU_SAVANE * oiseau_savane, struct PHACOCHERE * phacochere, struct GAZELLE * gazelle, struct ZEBRE * zebre, struct ANTILOPE * antilope, struct TERMITE * termite, struct INSECTE_SAVANE * insecte_savane, struct RACINE_SAVANE * racine_savane, struct FRUIT_SAVANE * fruit_savane, struct HERBE_SAVANE * herbe_savane, struct BUISSON * buisson);
void PARAMETRES_SIMULATION_DOS(struct VAUTOUR * vautour, struct LION * lion, struct GUEPARD * guepard, struct HYENE * hyene, struct CHACAL * chacal, struct MANGOUSTE * mangouste, struct SERPENT_SAVANE * serpent_savane, struct OISEAU_SAVANE * oiseau_savane, struct PHACOCHERE * phacochere, struct GAZELLE * gazelle, struct ZEBRE * zebre, struct ANTILOPE * antilope, struct TERMITE * termite, struct INSECTE_SAVANE * insecte_savane, struct RACINE_SAVANE * racine_savane, struct FRUIT_SAVANE * fruit_savane, struct HERBE_SAVANE * herbe_savane, struct BUISSON * buisson);
void RETOUR_A_NORME_DOS(struct VAUTOUR * vautour, struct LION * lion, struct GUEPARD * guepard, struct HYENE * hyene, struct CHACAL * chacal, struct MANGOUSTE * mangouste, struct SERPENT_SAVANE * serpent_savane, struct OISEAU_SAVANE * oiseau_savane, struct PHACOCHERE * phacochere, struct GAZELLE * gazelle, struct ZEBRE * zebre, struct ANTILOPE * antilope, struct TERMITE * termite, struct INSECTE_SAVANE * insecte_savane, struct RACINE_SAVANE * racine_savane, struct FRUIT_SAVANE * fruit_savane, struct HERBE_SAVANE * herbe_savane, struct BUISSON * buisson);

void SIMULATION_TRES(struct OURS *ours, struct LOUP *loup, struct LYNX *lynx, struct AIGLE *aigle, struct CERF *cerf, struct SANGLIER *sanglier, struct FAUCON *faucon, struct CHEUVREUIL *chevreuil, struct SERPENT *serpent, struct BLAIREAU *blaireau, struct RENARD *renard, struct CHAUVE_SOURIS *chauve_souris, struct HERISSON *herisson, struct LAPIN *lapin, struct RONGEUR *rongeur, struct ECUREUIL *ecureuil, struct OISEAU *oiseau, struct GRENOUILLE *grenouille, struct ESCARGOT *escargot, struct LARVES *larves, struct INSECTES *insectes, struct FOURMIS *fourmis, struct VERRE_DE_TERRE *verre_de_terre, struct CHAMPIGNON *champignon, struct RACINE *racine, struct FRUIT *fruit, struct GRAINE *graine, struct HERBE *herbe, struct FEUILLE *feuille);
void PARAMETRES_SIMULATION_TRES(struct OURS *ours, struct LOUP *loup, struct LYNX *lynx, struct AIGLE *aigle, struct CERF *cerf, struct SANGLIER *sanglier, struct FAUCON *faucon, struct CHEUVREUIL *chevreuil, struct SERPENT *serpent, struct BLAIREAU *blaireau, struct RENARD *renard, struct CHAUVE_SOURIS *chauve_souris, struct HERISSON *herisson, struct LAPIN *lapin, struct RONGEUR *rongeur, struct ECUREUIL *ecureuil, struct OISEAU *oiseau, struct GRENOUILLE *grenouille, struct ESCARGOT *escargot, struct LARVES *larves, struct INSECTES *insectes, struct FOURMIS *fourmis, struct VERRE_DE_TERRE *verre_de_terre, struct CHAMPIGNON *champignon, struct RACINE *racine, struct FRUIT *fruit, struct GRAINE *graine, struct HERBE *herbe, struct FEUILLE *feuille);
void RETOUR_A_NORME_TRES(struct OURS *ours, struct LOUP *loup, struct LYNX *lynx, struct AIGLE *aigle, struct CERF *cerf, struct SANGLIER *sanglier, struct FAUCON *faucon, struct CHEUVREUIL *chevreuil, struct SERPENT *serpent, struct BLAIREAU *blaireau, struct RENARD *renard, struct CHAUVE_SOURIS *chauve_souris, struct HERISSON *herisson, struct LAPIN *lapin, struct RONGEUR *rongeur, struct ECUREUIL *ecureuil, struct OISEAU *oiseau, struct GRENOUILLE *grenouille, struct ESCARGOT *escargot, struct LARVES *larves, struct INSECTES *insectes, struct FOURMIS *fourmis, struct VERRE_DE_TERRE *verre_de_terre, struct CHAMPIGNON *champignon, struct RACINE *racine, struct FRUIT *fruit, struct GRAINE *graine, struct HERBE *herbe, struct FEUILLE *feuille);
#endif //EVOLUTION_BIBLIO_H
