#include "BIBLIO.h"


void SIMULATION_UNO(struct ORQUE *orque, struct LEOPARD_DE_MER *leopard_de_mer, struct MANCHOT_EMPEREUR *manchot_empereur, struct ELEPHANT_DE_MER *elephant_de_mer, struct PHOQUE *phoque, struct BALEINE_A_BOSSE *baleine_a_bosse, struct GROS_POISSONS *gros_poissons, struct PETITS_POISSONS *petits_poissons, struct KRILL *krill)
{
    printf("\n");
    printf("*******************************************************************************************************\n");
    printf("                                        DEBUT DE LA SIMULATION\n");
    printf("*******************************************************************************************************\n");
    printf("-------------------------------------------------------------------------------------------------------\n");
    printf("AVANT\n");
    printf("-------------------------------------------------------------------------------------------------------\n");
    printf("=> ORQUE               : %d\n", orque->Taille_AVANT);
    printf("=> LEOPARD DE MER      : %d\n", leopard_de_mer->Taille_AVANT);
    printf("=> MANCHOT EMPEREUR    : %d\n", manchot_empereur->Taille_AVANT);
    printf("=> ELEPHANT DE MER     : %d\n", elephant_de_mer->Taille_AVANT);
    printf("=> PHOQUE              : %d\n", phoque->Taille_AVANT);
    printf("=> BALEINE A BOSSE     : %d\n", baleine_a_bosse->Taille_AVANT);
    printf("=> GROS POISSON        : %d\n", gros_poissons->Taille_AVANT);
    printf("=> PETIT POISSON       : %d\n", petits_poissons->Taille_AVANT);
    printf("=> KRILL (kilos)       : %d\n", krill->Taille_AVANT);
    printf("-------------------------------------------------------------------------------------------------------\n");
    printf("APRES\n");
    printf("-------------------------------------------------------------------------------------------------------\n");
//**********************************************************************************************************************
    orque->Taille_APRES            = orque->Taille_AVANT;
    leopard_de_mer->Taille_APRES   = leopard_de_mer->Taille_AVANT;
    manchot_empereur->Taille_APRES= manchot_empereur->Taille_AVANT;
    elephant_de_mer->Taille_APRES  = elephant_de_mer->Taille_AVANT;
    phoque->Taille_APRES           = phoque->Taille_AVANT;
    baleine_a_bosse->Taille_APRES  = baleine_a_bosse->Taille_AVANT;
    gros_poissons->Taille_APRES    = gros_poissons->Taille_AVANT;
    petits_poissons->Taille_APRES  = petits_poissons->Taille_AVANT;
    krill->Taille_APRES            = krill->Taille_AVANT;

//**********************************************************************************************************************

    petits_poissons->Taille_APRES  = (int)(petits_poissons->Taille_AVANT * (float)krill->Taille_AVANT / petits_poissons->Taille_AVANT);

    gros_poissons->Taille_APRES    = (int)(gros_poissons->Taille_AVANT * (float)petits_poissons->Taille_AVANT / gros_poissons->Taille_AVANT);

    baleine_a_bosse->Taille_APRES  = (int)(baleine_a_bosse->Taille_AVANT * (float)krill->Taille_AVANT / baleine_a_bosse->Taille_AVANT);

    phoque->Taille_APRES           = (int)(phoque->Taille_AVANT * (float)petits_poissons->Taille_AVANT / petits_poissons->Taille_AVANT);

    elephant_de_mer->Taille_APRES  = (int)(elephant_de_mer->Taille_AVANT * (float)gros_poissons->Taille_AVANT / elephant_de_mer->Taille_AVANT);

    manchot_empereur->Taille_APRES = (int)(manchot_empereur->Taille_AVANT * ((0.1*(float)gros_poissons->Taille_AVANT/manchot_empereur->Taille_AVANT) + (0.9*(float)petits_poissons->Taille_AVANT /manchot_empereur->Taille_AVANT)));

    leopard_de_mer->Taille_APRES   = (int)(leopard_de_mer->Taille_AVANT * ((float)manchot_empereur->Taille_AVANT + (float)gros_poissons->Taille_AVANT) / (2 * leopard_de_mer->Taille_AVANT));

    orque->Taille_APRES            = (int)(orque->Taille_AVANT * ((float)manchot_empereur->Taille_AVANT + (float)elephant_de_mer->Taille_AVANT + (float)baleine_a_bosse->Taille_AVANT + (float)leopard_de_mer->Taille_AVANT + (float)phoque->Taille_AVANT) / (5 * orque->Taille_AVANT));

// *********************************************************************************************************************
    float EVOLUTION_ORQUES            = ((float)(orque->Taille_APRES             - orque->Taille_AVANT)/orque->Taille_AVANT)*100;
    float EVOLUTION_LEOPARD_DE_MER    = ((float)(leopard_de_mer->Taille_APRES    - leopard_de_mer->Taille_AVANT)/leopard_de_mer->Taille_AVANT)*100;
    float EVOLUTION_MANCHEAU_EMPEREUR = ((float)(manchot_empereur->Taille_APRES  - manchot_empereur->Taille_AVANT)/manchot_empereur->Taille_AVANT)*100;
    float EVOLUTION_ELEPHANT_DE_MER   = ((float)(elephant_de_mer->Taille_APRES   - elephant_de_mer->Taille_AVANT)/elephant_de_mer->Taille_AVANT)*100;
    float EVOLUTION_PHOQUE            = ((float)(phoque->Taille_APRES            - phoque->Taille_AVANT)/phoque->Taille_AVANT)*100;
    float EVOLUTION_BALEINE_A_BOSSE   = ((float)(baleine_a_bosse->Taille_APRES   - baleine_a_bosse->Taille_AVANT)/baleine_a_bosse->Taille_AVANT)*100;
    float EVOLUTION_GROS_POISSONS     = ((float)(gros_poissons->Taille_APRES     - gros_poissons->Taille_AVANT)/gros_poissons->Taille_AVANT)*100;
    float EVOLUTION_PETITS_POISSONS   = ((float)(petits_poissons->Taille_APRES   - petits_poissons->Taille_AVANT )/petits_poissons->Taille_AVANT)*100;
    float EVOLUTION_KRILL             = ((float)(krill->Taille_APRES             - krill->Taille_AVANT)/krill->Taille_AVANT)*100;

    printf("=> ORQUE              : %d (%.2f %%)\n",orque->Taille_APRES, EVOLUTION_ORQUES);
    printf("=> LEOPARD DE MER     : %d (%.2f %%)\n",leopard_de_mer->Taille_APRES, EVOLUTION_LEOPARD_DE_MER);
    printf("=> MANCHOT EMPEREUR   : %d (%.2f %%)\n",manchot_empereur->Taille_APRES, EVOLUTION_MANCHEAU_EMPEREUR);
    printf("=> ELEPHANT DE MER    : %d (%.2f %%)\n",elephant_de_mer->Taille_APRES, EVOLUTION_ELEPHANT_DE_MER);
    printf("=> PHOQUE             : %d (%.2f %%)\n",phoque->Taille_APRES, EVOLUTION_PHOQUE);
    printf("=> BALEINE A BOSSE    : %d (%.2f %%)\n",baleine_a_bosse->Taille_APRES, EVOLUTION_BALEINE_A_BOSSE);
    printf("=> GROS POISSON       : %d (%.2f %%)\n",gros_poissons->Taille_APRES, EVOLUTION_GROS_POISSONS);
    printf("=> PETIT POISSON      : %d (%.2f %%)\n",petits_poissons->Taille_APRES, EVOLUTION_PETITS_POISSONS);
    printf("=> KRILL (kilos)      : %d (%.2f %%)\n",krill->Taille_APRES, EVOLUTION_KRILL);




//**********************************************************************************************************************
    printf("\n");
    printf("*******************************************************************************************************\n");
    printf("                                        FIN DE LA SIMULATION\n");
    printf("*******************************************************************************************************\n");
    printf("\n");
}
void PARAMETRES_SIMULATION_UNO(struct ORQUE *orque, struct LEOPARD_DE_MER *leopard_de_mer, struct MANCHOT_EMPEREUR *manchot_empereur, struct ELEPHANT_DE_MER *elephant_de_mer, struct PHOQUE *phoque, struct BALEINE_A_BOSSE *baleine_a_bosse, struct GROS_POISSONS *gros_poissons, struct PETITS_POISSONS *petits_poissons, struct KRILL *krill)
{
    bool MODIFICATION = true;
    int choix_PARAMETRE;
    int NEW =2;

    while (MODIFICATION==true)
    {
        printf("*******************************************************************************************************\n");
        printf("                                        PARAMETRES DE LA SIMULATION\n");
        printf("*******************************************************************************************************\n");
        printf("QUEL PARAMETRE VOULEZ-VOUS MODIFIER ?\n");
        printf("1 - Orques\n");
        printf("2 - Leopards de mer\n");
        printf("3 - Mancheaux empereurs\n");
        printf("4 - Elephants de mer\n");
        printf("5 - Phoques\n");
        printf("6 - Baleines a bosse\n");
        printf("7 - Gros poissons\n");
        printf("8 - Petits poissons\n");
        printf("9 - Krill\n");
        printf("0 - Quitter\n");
        printf("-------------------------------------------------------------------------------------------------------\n");
        printf("\n");

        scanf("%d", &choix_PARAMETRE);

        switch (choix_PARAMETRE)
        {
            case 1:
                printf("Orques\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &orque->Taille_AVANT);
                }while (orque->Taille_AVANT < 1 || orque->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                orque->Modifie = true;
                NEW = 2;
                break;
            case 2:
                printf("Leopards de mer\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &leopard_de_mer->Taille_AVANT);
                }while (leopard_de_mer->Taille_AVANT < 1 || leopard_de_mer->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                leopard_de_mer->Modifie = true;
                NEW = 2;
                break;
            case 3:
                printf("Mancheaux empereurs\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &manchot_empereur->Taille_AVANT);
                }while (manchot_empereur->Taille_AVANT < 1 || manchot_empereur->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                manchot_empereur->Modifie = true;
                NEW = 2;
                break;
            case 4:
                printf("Elephants de mer\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &elephant_de_mer->Taille_AVANT);
                }while (elephant_de_mer->Taille_AVANT < 1 || elephant_de_mer->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                elephant_de_mer->Modifie = true;
                NEW = 2;
                break;
            case 5:
                printf("Phoques\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &phoque->Taille_AVANT);
                }while (phoque->Taille_AVANT < 1 || phoque->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                phoque->Modifie = true;
                NEW = 2;
                break;
            case 6:
                printf("Baleines a bosse\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &baleine_a_bosse->Taille_AVANT);
                }while (baleine_a_bosse->Taille_AVANT < 1 || baleine_a_bosse->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                baleine_a_bosse->Modifie = true;
                NEW = 2;
                break;
            case 7:
                printf("Gros poissons\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &gros_poissons->Taille_AVANT);
                }while (gros_poissons->Taille_AVANT < 1 || gros_poissons->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                gros_poissons->Modifie = true;
                NEW = 2;
                break;
            case 8:
                printf("Petits poissons\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &petits_poissons->Taille_AVANT);
                }while (petits_poissons->Taille_AVANT < 1 || petits_poissons->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                petits_poissons->Modifie = true;
                NEW = 2;
                break;
            case 9:
                printf("Krill\n");
                do {
                    printf("Taille prochaine generation (entre 1 et 199): ");
                    scanf("%d", &krill->Taille_AVANT);
                }while (krill->Taille_AVANT < 1 || krill->Taille_AVANT > 199);
                printf("\n");
                do {
                    printf("Voulez-vous modifier un autre parametre ? (OUI = 1, NON = 0)\n");
                    scanf("%d", &NEW);
                }while (NEW !=0 && NEW !=1);
                if (NEW == 0)
                {
                    MODIFICATION = false;
                }
                krill->Modifie = true;
                NEW = 2;
                break;
            default:
                printf("Retour Menu\n");
                MODIFICATION = false;
                break;
        }
    }
}
void RETOUR_A_NORME_UNO(struct ORQUE *orque, struct LEOPARD_DE_MER *leopard_de_mer, struct MANCHOT_EMPEREUR *manchot_empereur, struct ELEPHANT_DE_MER *elephant_de_mer, struct PHOQUE *phoque, struct BALEINE_A_BOSSE *baleine_a_bosse, struct GROS_POISSONS *gros_poissons, struct PETITS_POISSONS *petits_poissons, struct KRILL *krill)
{
    if (orque->Modifie == true)
    {
        orque->Taille_AVANT = 100;
    }
    if (leopard_de_mer->Modifie == true)
    {
        leopard_de_mer->Taille_AVANT = 100;
    }
    if (manchot_empereur->Modifie == true)
    {
        manchot_empereur->Taille_AVANT = 100;
    }
    if (elephant_de_mer->Modifie == true)
    {
        elephant_de_mer->Taille_AVANT = 100;
    }
    if (phoque->Modifie == true)
    {
        phoque->Taille_AVANT = 100;
    }
    if (baleine_a_bosse->Modifie == true)
    {
        baleine_a_bosse->Taille_AVANT = 100;
    }
    if (gros_poissons->Modifie == true)
    {
        gros_poissons->Taille_AVANT = 100;
    }
    if (petits_poissons->Modifie == true)
    {
        petits_poissons->Taille_AVANT = 100;
    }
    if (krill->Modifie == true)
    {
        krill->Taille_AVANT = 100;
    }
};