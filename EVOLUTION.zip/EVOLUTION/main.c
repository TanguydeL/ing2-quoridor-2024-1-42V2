#include "BIBLIO.h"

bool REGEN = false;
bool continuer = true;




int main() {
    int choix_SIM;
    int MODIF;

    srand(time(NULL));

    struct ORQUE orque                         = {100, 0, 0};
    struct LEOPARD_DE_MER leopard_de_mer       = {100, 0, 0};
    struct MANCHOT_EMPEREUR manchot_empereur   = {100, 0, 0};
    struct ELEPHANT_DE_MER elephant_de_mer     = {100, 0, 0};
    struct PHOQUE phoque                       = {100, 0, 0};
    struct BALEINE_A_BOSSE baleine_a_bosse     = {100, 0, 0};
    struct GROS_POISSONS gros_poissons         = {100, 0, 0};
    struct PETITS_POISSONS petits_poissons     = {100, 0, 0};
    struct KRILL krill                         = {100, 0, 0};

    struct VAUTOUR vautour                     = {100, 0, 0};
    struct LION lion                           = {100, 0, 0};
    struct GUEPARD guepard                     = {100, 0, 0};
    struct HYENE hyene                         = {100, 0, 0};
    struct CHACAL chacal                       = {100, 0, 0};
    struct MANGOUSTE mangouste                 = {100, 0, 0};
    struct SERPENT_SAVANE serpent_savane       = {100, 0, 0};
    struct OISEAU_SAVANE oiseau_savane         = {100, 0, 0};
    struct PHACOCHERE phacochere               = {100, 0, 0};
    struct GAZELLE gazelle                     = {100, 0, 0};
    struct ZEBRE zebre                         = {100, 0, 0};
    struct ANTILOPE antilope                   = {100, 0, 0};
    struct TERMITE termite                     = {100, 0, 0};
    struct INSECTE_SAVANE insecte_savane       = {100, 0, 0};
    struct RACINE_SAVANE racine_savane         = {100, 0, 0};
    struct FRUIT_SAVANE fruit_savane           = {100, 0, 0};
    struct HERBE_SAVANE herbe_savane           = {100, 0, 0};
    struct BUISSON buisson                     = {100, 0, 0};

    struct OURS ours                           = {100, 0, 0};
    struct LOUP loup                           = {100, 0, 0};
    struct LYNX lynx                           = {100, 0, 0};
    struct AIGLE aigle                         = {100, 0, 0};
    struct CERF cerf                           = {100, 0, 0};
    struct SANGLIER sanglier                   = {100, 0, 0};
    struct FAUCON faucon                       = {100, 0, 0};
    struct CHEUVREUIL chevreuil                = {100, 0, 0};
    struct SERPENT serpent                     = {100, 0, 0};
    struct BLAIREAU blaireau                   = {100, 0, 0};
    struct RENARD renard                       = {100, 0, 0};
    struct CHAUVE_SOURIS chauve_souris         = {100, 0, 0};
    struct HERISSON herisson                   = {100, 0, 0};
    struct LAPIN lapin                         = {100, 0, 0};
    struct RONGEUR rongeur                     = {100, 0, 0};
    struct ECUREUIL ecureuil                   = {100, 0, 0};
    struct OISEAU oiseau                       = {100, 0, 0};
    struct GRENOUILLE grenouille               = {100, 0, 0};
    struct ESCARGOT escargot                   = {100, 0, 0};
    struct LARVES larves                       = {100, 0, 0};
    struct INSECTES insectes                   = {100, 0, 0};
    struct FOURMIS fourmis                     = {100, 0, 0};
    struct VERRE_DE_TERRE verre_de_terre       = {100, 0, 0};
    struct CHAMPIGNON champignon               = {100, 0, 0};
    struct RACINE racine                       = {100, 0, 0};
    struct FRUIT fruit                         = {100, 0, 0};
    struct GRAINE graine                       = {100, 0, 0};
    struct HERBE herbe                         = {100, 0, 0};
    struct FEUILLE feuille                     = {100, 0, 0};





    while (continuer==true)
    {
        printf("ENTREZ VOTRE CHOIX\n");
        printf("0 - Quitter\n");
        printf("1 - (ARTIQUE) Lancer une simulation\n");
        printf("2 - (ARTIQUE) Modifier les parametres de la simulation\n");
        printf("3 - Regles de simulation\n");
        printf("4 - (SAVANNE) Lancer une simulation\n");
        printf("5 - (SAVANNE) Modifier les parametres de la simulation\n");
        printf("6 - (FORET) Lancer une simulation\n");
        printf("7 - (FORET) Modifier les parametres de la simulation\n");
        scanf("%d", &choix_SIM);
        switch (choix_SIM)
        {
            case 0:
                printf("\n");
                printf("Fin du programme\n");
                continuer = false;
                break;

            case 1:
                SIMULATION_UNO(&orque, &leopard_de_mer, &manchot_empereur, &elephant_de_mer, &phoque, &baleine_a_bosse, &gros_poissons, &petits_poissons, &krill);
                krill.Taille_AVANT = krill.Taille_APRES;
                petits_poissons.Taille_AVANT = petits_poissons.Taille_APRES;
                gros_poissons.Taille_AVANT = gros_poissons.Taille_APRES;
                baleine_a_bosse.Taille_AVANT = baleine_a_bosse.Taille_APRES;
                phoque.Taille_AVANT = phoque.Taille_APRES;
                elephant_de_mer.Taille_AVANT = elephant_de_mer.Taille_APRES;
                manchot_empereur.Taille_AVANT = manchot_empereur.Taille_APRES;
                leopard_de_mer.Taille_AVANT = leopard_de_mer.Taille_APRES;
                orque.Taille_AVANT = orque.Taille_APRES;
                if (REGEN==true)
                {
                    RETOUR_A_NORME_UNO(&orque, &leopard_de_mer, &manchot_empereur, &elephant_de_mer, &phoque, &baleine_a_bosse, &gros_poissons, &petits_poissons, &krill);
                }
                break;

            case 2:
                PARAMETRES_SIMULATION_UNO(&orque, &leopard_de_mer, &manchot_empereur, &elephant_de_mer, &phoque, &baleine_a_bosse, &gros_poissons, &petits_poissons, &krill);
                break;

            case 3:
                printf("*******************************************************************************************************\n");
                printf("                                        REGLES DE SIMULATION\n");
                printf("*******************************************************************************************************\n");
                printf("\n");
                printf("Voulez vous activer la regeneration des especes apres modification ? (OUI = 1, NON = 0)\n");
                if (REGEN==true)
                {
                    printf("Regeneration: ACTIVE\n");
                }
                else
                {
                    printf("Regeneration: ACTIVE\n");
                }
                scanf("%d", &MODIF);
                if (MODIF == 1)
                {
                    REGEN = true;
                }
                else
                {
                    REGEN = false;
                }

            case 4:
                SIMULATION_DOS(&vautour, &lion, &guepard, &hyene, &chacal, &mangouste, &serpent_savane, &oiseau_savane, &phacochere, &gazelle, &zebre, &antilope, &termite, &insecte_savane, &racine_savane, &fruit_savane, &herbe_savane, &buisson);
                herbe_savane.Taille_AVANT = herbe_savane.Taille_APRES;
                fruit_savane.Taille_AVANT = fruit_savane.Taille_APRES;
                racine_savane.Taille_AVANT = racine_savane.Taille_APRES;
                insecte_savane.Taille_AVANT = insecte_savane.Taille_APRES;
                termite.Taille_AVANT = termite.Taille_APRES;
                antilope.Taille_AVANT = antilope.Taille_APRES;
                zebre.Taille_AVANT = zebre.Taille_APRES;
                gazelle.Taille_AVANT = gazelle.Taille_APRES;
                phacochere.Taille_AVANT = phacochere.Taille_APRES;
                oiseau_savane.Taille_AVANT = oiseau_savane.Taille_APRES;
                serpent_savane.Taille_AVANT = serpent_savane.Taille_APRES;
                mangouste.Taille_AVANT = mangouste.Taille_APRES;
                chacal.Taille_AVANT = chacal.Taille_APRES;
                hyene.Taille_AVANT = hyene.Taille_APRES;
                guepard.Taille_AVANT = guepard.Taille_APRES;
                lion.Taille_AVANT = lion.Taille_APRES;
                vautour.Taille_AVANT = vautour.Taille_APRES;
                if (REGEN==true)
                {
                    RETOUR_A_NORME_DOS(&vautour, &lion, &guepard, &hyene, &chacal, &mangouste, &serpent_savane, &oiseau_savane, &phacochere, &gazelle, &zebre, &antilope, &termite, &insecte_savane, &racine_savane, &fruit_savane, &herbe_savane, &buisson);
                }
                break;
            case 5:
                PARAMETRES_SIMULATION_DOS(&vautour, &lion, &guepard, &hyene, &chacal, &mangouste, &serpent_savane, &oiseau_savane, &phacochere, &gazelle, &zebre, &antilope, &termite, &insecte_savane, &racine_savane, &fruit_savane, &herbe_savane, &buisson);
                break;
            case 6:
                SIMULATION_TRES(&ours, &loup, &lynx, &aigle, &cerf, &sanglier, &faucon, &chevreuil, &serpent, &blaireau, &renard, &chauve_souris, &herisson, &lapin, &rongeur, &ecureuil, &oiseau, &grenouille, &escargot, &larves, &insectes, &fourmis, &verre_de_terre, &champignon, &racine, &fruit, &graine, &herbe, &feuille);
                feuille.Taille_AVANT = feuille.Taille_APRES;
                herbe.Taille_AVANT = herbe.Taille_APRES;
                graine.Taille_AVANT = graine.Taille_APRES;
                fruit.Taille_AVANT = fruit.Taille_APRES;
                racine.Taille_AVANT = racine.Taille_APRES;
                champignon.Taille_AVANT = champignon.Taille_APRES;
                verre_de_terre.Taille_AVANT = verre_de_terre.Taille_APRES;
                fourmis.Taille_AVANT = fourmis.Taille_APRES;
                insectes.Taille_AVANT = insectes.Taille_APRES;
                larves.Taille_AVANT = larves.Taille_APRES;
                escargot.Taille_AVANT = escargot.Taille_APRES;
                grenouille.Taille_AVANT = grenouille.Taille_APRES;
                oiseau.Taille_AVANT = oiseau.Taille_APRES;
                ecureuil.Taille_AVANT = ecureuil.Taille_APRES;
                rongeur.Taille_AVANT = rongeur.Taille_APRES;
                lapin.Taille_AVANT = lapin.Taille_APRES;
                herisson.Taille_AVANT = herisson.Taille_APRES;
                chauve_souris.Taille_AVANT = chauve_souris.Taille_APRES;
                renard.Taille_AVANT = renard.Taille_APRES;
                blaireau.Taille_AVANT = blaireau.Taille_APRES;
                serpent.Taille_AVANT = serpent.Taille_APRES;
                chevreuil.Taille_AVANT = chevreuil.Taille_APRES;
                faucon.Taille_AVANT = faucon.Taille_APRES;
                sanglier.Taille_AVANT = sanglier.Taille_APRES;
                cerf.Taille_AVANT = cerf.Taille_APRES;
                aigle.Taille_AVANT = aigle.Taille_APRES;
                lynx.Taille_AVANT = lynx.Taille_APRES;
                loup.Taille_AVANT = loup.Taille_APRES;
                ours.Taille_AVANT = ours.Taille_APRES;
                if (REGEN==true)
                {
                    RETOUR_A_NORME_TRES(&ours, &loup, &lynx, &aigle, &cerf, &sanglier, &faucon, &chevreuil, &serpent, &blaireau, &renard, &chauve_souris, &herisson, &lapin, &rongeur, &ecureuil, &oiseau, &grenouille, &escargot, &larves, &insectes, &fourmis, &verre_de_terre, &champignon, &racine, &fruit, &graine, &herbe, &feuille);
                }
                break;

            case 7:
                PARAMETRES_SIMULATION_TRES(&ours, &loup, &lynx, &aigle, &cerf, &sanglier, &faucon, &chevreuil, &serpent, &blaireau, &renard, &chauve_souris, &herisson, &lapin, &rongeur, &ecureuil, &oiseau, &grenouille, &escargot, &larves, &insectes, &fourmis, &verre_de_terre, &champignon, &racine, &fruit, &graine, &herbe, &feuille);
                break;

            default:
                printf("\n");
                printf("Erreur de saisie\n");
                break;

        }
    }
    return 0;
}
