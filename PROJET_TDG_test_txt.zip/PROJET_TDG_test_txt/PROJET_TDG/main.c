#include "biblio.h"

int main() {
    char filename[256];
    //boucle pour changer de fichier à volonté
    do {
        ReseauTrophique *monReseau = initReseau();

        printf("Entrez le nom du fichier du reseau trophique : ");
        scanf("%255s", filename); // Lire le nom du fichier avec une taille maximale de 255 caractères

        lireFichierEtConstruireReseau(filename, monReseau);
        afficherReseau(monReseau);
        PredetSucc(monReseau);
        affichagePredecesseuretSuccesseur(monReseau);

        // Libération de la mémoire
        for (int i = 0; i < monReseau->nbSommets; i++) {
            free(monReseau->sommets[i].nom);
        }
        free(monReseau->sommets);
        free(monReseau->arcs);
        free(monReseau);

    }while(filename != "quitter");
    return 0;
}
