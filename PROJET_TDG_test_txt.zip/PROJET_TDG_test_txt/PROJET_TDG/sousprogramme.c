
#include "biblio.h"

ReseauTrophique* initReseau() {
    ReseauTrophique *reseau = malloc(sizeof(ReseauTrophique));
    reseau->sommets = NULL;
    reseau->arcs = NULL;
    reseau->nbSommets = 0;
    reseau->nbArcs = 0;
    reseau->hauteur_trophique = 0;
    return reseau;
}

void ajouterSommet(ReseauTrophique *reseau, char *nom, int niveau, int nbr_espece,int numero) {
    reseau->sommets = realloc(reseau->sommets, (reseau->nbSommets + 1) * sizeof(Sommet));
    reseau->sommets[reseau->nbSommets].nom = strdup(nom); // Utilisation de strdup pour copier le nom
    reseau->sommets[reseau->nbSommets].niveauTrophique = niveau;
    reseau->sommets[reseau->nbSommets].nbr_especes = nbr_espece;
    reseau->sommets[reseau->nbSommets].numero = numero;
    reseau->sommets[reseau->nbSommets].predecesseur = NULL;
    reseau->sommets[reseau->nbSommets].successeur = NULL;
    reseau->sommets[reseau->nbSommets].nbr_pred = 0;
    reseau->sommets[reseau->nbSommets].nbr_succ = 0;
    if(reseau->sommets[reseau->nbSommets].niveauTrophique > reseau->hauteur_trophique) {
        reseau->hauteur_trophique = reseau->sommets[reseau->nbSommets].niveauTrophique;
    }
    reseau->nbSommets++;
}

void ajouterArc(ReseauTrophique *reseau, int from, int to, float poids) {
    reseau->arcs = realloc(reseau->arcs, (reseau->nbArcs + 1) * sizeof(Arc));
    reseau->arcs[reseau->nbArcs].from = from;
    reseau->arcs[reseau->nbArcs].to = to;
    reseau->arcs[reseau->nbArcs].poids = poids;
    reseau->nbArcs++;
}

void PredetSucc(ReseauTrophique *reseau) {
    for (int i = 0; i < reseau->nbArcs; i++) {
        int from = reseau->arcs[i].from;
        int to =  reseau->arcs[i].to;

        for(int j = 0; j < reseau->nbSommets; j++) {
            if(reseau->sommets[j].numero == from) {
                for(int k = 0; k < reseau->nbSommets; k++) {
                    if(reseau->sommets[k].numero == to) {
                        // sommet j est le predecesseur de sommet k
                        reseau->sommets[k].predecesseur = realloc(reseau->sommets[k].predecesseur, (reseau->sommets[k].nbr_pred + 1) * sizeof(Sommet*));
                        reseau->sommets[k].predecesseur[reseau->sommets[k].nbr_pred] = &reseau->sommets[j];
                        reseau->sommets[k].nbr_pred++;
                        // sommet k est le successeur de sommet j
                        reseau->sommets[j].successeur = realloc(reseau->sommets[j].successeur, (reseau->sommets[j].nbr_succ + 1) * sizeof(Sommet*));
                        reseau->sommets[j].successeur[reseau->sommets[j].nbr_succ] = &reseau->sommets[k];
                        reseau->sommets[j].nbr_succ++;
                    }
                }
            }
        }
    }
}


void afficherReseau(ReseauTrophique *reseau) {
    float max_liens = 0;
    max_liens = reseau->nbSommets * (reseau->nbSommets - 1);
    reseau->densité = (float)reseau->nbArcs/max_liens;
    printf("Reseau Trophique avec %d sommets, %d arcs et de hauteur throphique : %d\n et de densité : %0.3f ",
        reseau->nbSommets, reseau->nbArcs,reseau->hauteur_trophique,reseau->densité);
    for (int i = 0; i < reseau->nbSommets; i++) {
        printf("Liste des sommets : "
               "Sommet %d: %s, Niveau Trophique: %d,Quantité: %d\n", i, reseau->sommets[i].nom, reseau->sommets[i].niveauTrophique,reseau->sommets[i].nbr_especes);
    }
    for (int i = 0; i < reseau->nbArcs; i++) {
        printf("Liste des aretes : "
               "Arc %d: de %d a %d, Poids: %.2f\n", i, reseau->arcs[i].from, reseau->arcs[i].to, reseau->arcs[i].poids);
    }
    affichagePredecesseuretSuccesseur(reseau);
}

void affichagePredecesseuretSuccesseur(ReseauTrophique *reseau) {
    PredetSucc(reseau);
    for(int i = 0;i < reseau->nbSommets; i++) {
        printf("Les predecesseurs de %s sont : \n", reseau->sommets[i].nom);
        if(reseau->sommets[i].nbr_pred == 0) {
            printf("Aucun\n");
        }
        else {
            for (int j = 0; j < reseau->sommets[i].nbr_pred; j++) {
                printf("%s\n", reseau->sommets[i].predecesseur[j]->nom);
            }
        }
        printf("Les successeurs de %s sont : \n", reseau->sommets[i].nom);
        if(reseau->sommets[i].nbr_succ == 0) {
            printf("Aucun\n");
        }
        else {
            for (int j = 0; j < reseau->sommets[i].nbr_succ; j++) {
                printf("%s\n", reseau->sommets[i].successeur[j]->nom);
            }
        }
    }
}


void lireFichierEtConstruireReseau(const char *filename, ReseauTrophique *reseau) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        perror("Erreur lors de l'ouverture du fichier");
        return;
    }

    char line[1024];
    while (fgets(line, sizeof(line), file)) {
        if (line[0] == '#' || line[0] == '\n') continue; // Ignorer les commentaires et les lignes vides
        char type;
        char nom[100];
        int niveau, from, to, nbr_espece, numero;
        float poids;

        if (sscanf(line, "%c, %99[^,], %d, %d, %d", &type, nom, &numero, &niveau, &nbr_espece) == 5 && type == 'S') {
            ajouterSommet(reseau, nom, niveau, nbr_espece, numero);
        } else if (sscanf(line, "%c, %d, %d, %f", &type, &from, &to, &poids) == 4 && type == 'A') {
            ajouterArc(reseau, from, to, poids);
        }
    }

    fclose(file);
}

void moteur_de_recherche(ReseauTrophique *reseau) {
    int choix;
    int nbr;
    char nom[100];
    int verification = 0;
    int sommet = 0;
    int taille = 0;
    int tab[taille];
    do {
        printf("Selon quelle information voulez vous faire votre recherche ?\n"
           "1 : nom\n"
           "2 : nbr de predecesseurs\n"
           "3 : nbr de successeurs\n"
           "4 : QUITTER\n");
        scanf("%d",&choix);
        switch (choix) {
            case 1:
                printf("Quel est le nom du sommet que vous rechercher ? (remplacer les espaces par _)\n");
                scanf("%s", nom);
                for(int i = 0; i < reseau->nbSommets; i++) {
                    if(strcmp(reseau->sommets[i].nom, nom) == 0) {
                        verification = 1;
                        sommet = i;
                    }
                }
                if(verification == 1) {
                    printf("Votre sommet est : %s\n"
                           "il y a %d predecesseur(s) et %d successeur(s)\n"
                           "il est de niveau trophique %d\n"
                           "et cette espece compte %d membres\n",
                           reseau->sommets[sommet].nom,reseau->sommets[sommet].nbr_pred,reseau->sommets[sommet].nbr_succ,reseau->sommets[sommet].niveauTrophique,reseau->sommets[sommet].nbr_especes);
                }
                else {
                    printf("Votre sommet n'existe pas\n");
                }
                verification = 0;
                break;
            case 2:
                printf("Combien de predecesseurs doivent avoir vos sommets ?\n");
                scanf("%d",&nbr);
                for(int i = 0; i < reseau->nbSommets; i++) {
                     if(reseau->sommets[i].nbr_pred == nbr) {
                         verification = 1;
                         tab[taille] = i;
                         taille++;
                     }
                }
                if(verification == 1) {
                     for(int i = 0; i < taille; i++) {
                         for(int j = 0; j < reseau->nbSommets; j++) {
                             if(tab[i] == j) {
                                 printf("le sommet : %s correspond\n",reseau->sommets[j].nom);
                             }
                         }
                     }
                }
                else {
                    printf("Aucun sommet ne correspond\n");
                }
                nbr = 0;
                verification = 0;
                break;
            case 3:
                printf("Combien de successeurs doivent avoir vos sommets ?\n");
                scanf("%d",&nbr);
                for(int i = 0; i < reseau->nbSommets; i++) {
                    if(reseau->sommets[i].nbr_succ == nbr) {
                        verification = 1;
                        tab[taille] = i;
                        taille++;
                    }
                }
                if(verification == 1) {
                    for(int i = 0; i < taille; i++) {
                        for(int j = 0; j < reseau->nbSommets; j++) {
                            if(tab[i] == j) {
                                printf("le sommet : %s correspond\n",reseau->sommets[j].nom);
                            }
                        }
                    }
                }
                else {
                    printf("Aucun sommet ne correspond\n");
                }
                nbr = 0;
                verification = 0;
                break;
        }
    }while(choix != 4);
}