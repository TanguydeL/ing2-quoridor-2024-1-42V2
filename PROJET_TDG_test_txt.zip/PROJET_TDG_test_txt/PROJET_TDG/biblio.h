//
// Created by thoma on 13/11/2024.
//

#ifndef PROJET_TDG_BIBLIO_H
#define PROJET_TDG_BIBLIO_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Structure pour un sommet (espèce)
typedef struct Sommet {
    char *nom;
    int niveauTrophique; // Niveau trophique de l'espèce
    int numero; // Numero du sommet
    int nbr_especes; // Nombre de représentant de l'espece
    struct Sommet **  successeur; // Liste des successeurs
    int nbr_succ;
    struct Sommet ** predecesseur; // Liste des prédecesseurs
    int nbr_pred;
} Sommet;

// Structure pour un arc (relation alimentaire)
typedef struct Arc {
    int from; // Index du sommet de départ
    int to; // Index du sommet d'arrivée
    float poids; // Poids de l'arc, par exemple la quantité de biomasse échangée
} Arc;

// Structure pour un réseau trophique
typedef struct ReseauTrophique {
    Sommet *sommets; // Tableau dynamique de sommets
    Arc *arcs; // Tableau dynamique d'arcs
    int nbSommets; // Nombre de sommets
    int nbArcs; // Nombre d'arcs
    int hauteur_trophique; // Distance du sommet de départ au sommet concerné
    float densité; // Densité de liaison
} ReseauTrophique;

ReseauTrophique* initReseau();
void ajouterSommet(ReseauTrophique *reseau, char *nom, int niveau, int nbr_espece,int numero);
void ajouterArc(ReseauTrophique *reseau, int from, int to, float poids);
void afficherReseau(ReseauTrophique *reseau);
void affichagePredecesseuretSuccesseur(ReseauTrophique *reseau);
void PredetSucc(ReseauTrophique *reseau);
void lireFichierEtConstruireReseau(const char *filename, ReseauTrophique *reseau);
void moteur_de_recherche(ReseauTrophique *reseau);

#endif //PROJET_TDG_BIBLIO_H
