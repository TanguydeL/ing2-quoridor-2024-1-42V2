#include "biblio.h"

//Création des tableaux de pred et de succ pour chaque sommet ( sans algo )
void PredetSucc(ReseauTrophique *reseau) {
    //Boucle des arcs
    for (int i = 0; i < reseau->nbArcs; i++) {
        //Récupération du point de départ et du point d'arrivé de chaque arc
        int from = reseau->arcs[i].from;
        int to =  reseau->arcs[i].to;
        //Boucle de sommets
        for(int j = 0; j < reseau->nbSommets; j++) {
            //Si le sommet est le point de départ d'un arc
            if(reseau->sommets[j].numero == from) {
                //Boucle de sommets
                for(int k = 0; k < reseau->nbSommets; k++) {
                    //Si le sommet est le point d'arrivé de l'arc
                    if(reseau->sommets[k].numero == to) {
                        // sommet j est le predecesseur de sommet k (allocation, ajout dans le tableau, incrémentation)
                        reseau->sommets[k].predecesseur = realloc(reseau->sommets[k].predecesseur, (reseau->sommets[k].nbr_pred + 1) * sizeof(Sommet*));
                        reseau->sommets[k].predecesseur[reseau->sommets[k].nbr_pred] = &reseau->sommets[j];
                        reseau->sommets[k].nbr_pred++;
                        // sommet k est le successeur de sommet j (allocation, ajout dans le tableau, incrémentation)
                        reseau->sommets[j].successeur = realloc(reseau->sommets[j].successeur, (reseau->sommets[j].nbr_succ + 1) * sizeof(Sommet*));
                        reseau->sommets[j].successeur[reseau->sommets[j].nbr_succ] = &reseau->sommets[k];
                        reseau->sommets[j].nbr_succ++;
                    }
                }
            }
        }
    }
}



//Moteur de recherche en fontion du nom, nbr pred et nbr succ
void moteur_de_recherche(ReseauTrophique *reseau) {
    //Initialisation des variables
    int choix;
    int nbr;
    char nom[100];
    int verification = 0;
    int sommet = 0;
    int taille = 0;
    int tab[taille];
    //Boucle de choix du menu
    do {
        printf("Selon quelle information voulez vous faire votre recherche ?\n"
           "1 : nom\n"
           "2 : nbr de predecesseurs\n"
           "3 : nbr de successeurs\n"
           "4 : chaine alimentaire\n"
           "5 : QUITTER\n");
        scanf("%d",&choix);
        switch (choix) {
            //Recherche en fonction du nom
            case 1:
                system("cls");
                printf("Quel est le nom du sommet que vous rechercher ? (remplacer les espaces par _)\n");
                scanf("%s", nom);
                //Recherche du sommet avec vérification d'existence
                for(int i = 0; i < reseau->nbSommets; i++) {
                    if(strcmp(reseau->sommets[i].nom, nom) == 0) {
                        verification = 1;
                        sommet = i;
                    }
                }
                //Affichage du sommet et de l'ensemble de ses informations
                if(verification == 1) {
                    printf("Votre sommet est : %s\n"
                           "il y a %d predecesseur(s) et %d successeur(s)\n"
                           "il est de niveau trophique %d\n"
                           "et cette espece compte %d membres\n",
                           reseau->sommets[sommet].nom,reseau->sommets[sommet].nbr_pred,reseau->sommets[sommet].nbr_succ,reseau->sommets[sommet].niveauTrophique,reseau->sommets[sommet].nbr_especes);
                }
                //Si inexistence
                else {
                    printf("Votre sommet n'existe pas\n");
                }
                //Remise à 0
                verification = 0;
                break;
            //Rechercher en fonction du nombre de predecesseurs
            case 2:
                system("cls");
                printf("Combien de predecesseurs doivent avoir vos sommets ?\n");
                scanf("%d",&nbr);
                //Recherche des sommets avec vérification d'existence
                for(int i = 0; i < reseau->nbSommets; i++) {
                     if(reseau->sommets[i].nbr_pred == nbr) {
                         verification = 1;
                         tab[taille] = i;
                         taille++;
                     }
                }
                //Affichage de la liste des sommets vérifiant le nombre de predecesseurs voulu
                if(verification == 1) {
                     for(int i = 0; i < taille; i++) {
                         for(int j = 0; j < reseau->nbSommets; j++) {
                             if(tab[i] == j) {
                                 printf("le sommet : %s correspond\n",reseau->sommets[j].nom);
                             }
                         }
                     }
                }
                //Si inexistence
                else {
                    printf("Aucun sommet ne correspond\n");
                }
                //Remise à 0
                nbr = 0;
                verification = 0;
                break;
            //Recherche en fonction du nombre de successeurs
            case 3:
                system("cls");
                printf("Combien de successeurs doivent avoir vos sommets ?\n");
                scanf("%d",&nbr);
                //Recherche des sommets avec vérification d'existence
                for(int i = 0; i < reseau->nbSommets; i++) {
                    if(reseau->sommets[i].nbr_succ == nbr) {
                        verification = 1;
                        tab[taille] = i;
                        taille++;
                    }
                }
                //Affichage de la liste des sommets vérifiant le nombre de successeurs voulu
                if(verification == 1) {
                    for(int i = 0; i < taille; i++) {
                        for(int j = 0; j < reseau->nbSommets; j++) {
                            if(tab[i] == j) {
                                printf("le sommet : %s correspond\n",reseau->sommets[j].nom);
                            }
                        }
                    }
                }
                //Si inexistence
                else {
                    printf("Aucun sommet ne correspond\n");
                }
                //Remise à 0
                nbr = 0;
                verification = 0;
                break;
                //Recherche en fonction du nombre de successeurs
            case 4:
                system("cls");
                trouverCheminVersProducteurs(reseau);
                break;
        }
    }while(choix != 5);
}

