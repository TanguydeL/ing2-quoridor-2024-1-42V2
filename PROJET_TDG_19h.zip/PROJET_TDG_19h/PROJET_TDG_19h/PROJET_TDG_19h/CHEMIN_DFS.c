//
// Created by thoma on 08/12/2024.
//
#include "biblio.h"



void afficherChemin(ReseauTrophique *reseau, int chemin[], int taille) {
    printf("Chaine de niveau %d : ", taille);
    for (int i = taille - 1; i >= 0; i--) {
        printf("%s (%d) -> ", reseau->sommets[chemin[i]].nom, i);
    }
    printf("FIN\n");
}

void dfsTrouverProducteurs(ReseauTrophique *reseau, int sommetIdx, int chemin[], int niveau, int visited[]) {
    visited[sommetIdx] = 1;
    chemin[niveau] = sommetIdx;

    if (reseau->sommets[sommetIdx].nbr_pred == 0) {
        afficherChemin(reseau, chemin, niveau + 1);
    } else {
        for (int i = 0; i < reseau->sommets[sommetIdx].nbr_pred; i++) {
            int predIdx = reseau->sommets[sommetIdx].predecesseur[i]->numero;
            if (!visited[predIdx]) {
                dfsTrouverProducteurs(reseau, predIdx, chemin, niveau + 1, visited);
            }
        }
    }

    visited[sommetIdx] = 0;
}

void trouverCheminVersProducteurs(ReseauTrophique *reseau) {
    char nom[256];
    printf("Entrez le nom du sommet pour lequel trouver les chemins vers les producteurs : ");
    scanf("%255s", nom);

    int sommetIdx = -1;
    for (int i = 0; i < reseau->nbSommets; i++) {
        if (strcmp(reseau->sommets[i].nom, nom) == 0) {
            sommetIdx = i;
            break;
        }
    }

    if (sommetIdx == -1) {
        printf("Sommet non trouvé.\n");
        return;
    }

    int *chemin = (int *)malloc(reseau->nbSommets * sizeof(int));
    int *visited = (int *)calloc(reseau->nbSommets, sizeof(int));

    printf("Chemins du sommet '%s' vers les producteurs :\n", nom);
    dfsTrouverProducteurs(reseau, sommetIdx, chemin, 0, visited);

    free(chemin);
    free(visited);
}
