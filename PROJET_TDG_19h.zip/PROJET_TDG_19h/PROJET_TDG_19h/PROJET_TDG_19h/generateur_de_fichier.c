#include "biblio.h"

//Ecrire le réseau au format CSV
void ecrireCSV(ReseauTrophique *reseau) {
    FILE *fpNodes = fopen("nodes.csv", "w");
    FILE *fpEdges = fopen("edges.csv", "w");

    // En-têtes pour Gephi
    fprintf(fpNodes, "Id,Label,NiveauTrophique\n");
    fprintf(fpEdges, "Source,Target,Weight\n");

    // Écrire les données des sommets
    for (int i = 0; i < reseau->nbSommets; i++) {
        fprintf(fpNodes, "%d,\"%s\",%d\n", reseau->sommets[i].numero, reseau->sommets[i].nom, reseau->sommets[i].niveauTrophique);
    }

    // Écrire les données des arcs
    for (int i = 0; i < reseau->nbArcs; i++) {
        fprintf(fpEdges, "%d,%d,%.2f\n", reseau->arcs[i].from, reseau->arcs[i].to, reseau->arcs[i].poids);
    }

    fclose(fpNodes);
    fclose(fpEdges);
}

//Ecrire le réseau au format DOT pour Graphviz
//Ecrire le réseau au format DOT pour Graphviz
void ecrireDot(ReseauTrophique *reseau, const char *filename) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        perror("Erreur lors de la création du fichier DOT");
        return;
    }

    fprintf(file, "digraph ReseauTrophique {\n");
    fprintf(file, "    node [shape=none, margin=0.4, fontsize=18];\n");

    for (int i = 0; i < reseau->nbSommets; i++) {
        char imgPath[256];
        sprintf(imgPath, "animaux/%s.png", reseau->sommets[i].nom);
        fprintf(file, "    %d [image=\"%s\", label=\"\\n%s\\nNiveau: %d\\nEspèces: %d\", labelloc=b, width=\".25\", height=\".25\"];\n",
                reseau->sommets[i].numero, imgPath, reseau->sommets[i].nom, reseau->sommets[i].niveauTrophique, reseau->sommets[i].nbr_especes);
    }

    // Set penwidth to increase the thickness of the arrows
    for (int i = 0; i < reseau->nbArcs; i++) {
        fprintf(file, "    %d -> %d [label=\"%.2f\", weight=\"%.2f\", penwidth=3.0, fontsize=24];\n",
                reseau->arcs[i].from, reseau->arcs[i].to, reseau->arcs[i].poids, reseau->arcs[i].poids);
    }

    fprintf(file, "}\n");
    fclose(file);
}

//Supprimer l'extension d'un nom de fichier
void retirerExtension(const char *filename, char *output) {
    strcpy(output, filename);
    char *dot = strrchr(output, '.');
    if (dot != NULL) *dot = '\0';
}