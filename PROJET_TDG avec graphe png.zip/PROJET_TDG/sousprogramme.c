#include "biblio.h"

ReseauTrophique* initReseau() {
    ReseauTrophique *reseau = malloc(sizeof(ReseauTrophique));
    reseau->sommets = NULL;
    reseau->arcs = NULL;
    reseau->nbSommets = 0;
    reseau->nbArcs = 0;
    return reseau;
}

void ajouterSommet(ReseauTrophique *reseau, char *nom, int niveau) {
    reseau->sommets = realloc(reseau->sommets, (reseau->nbSommets + 1) * sizeof(Sommet));
    reseau->sommets[reseau->nbSommets].nom = strdup(nom);
    reseau->sommets[reseau->nbSommets].niveauTrophique = niveau;
    reseau->sommets[reseau->nbSommets].id = reseau->nbSommets;  // Utilise l'index comme ID
    reseau->nbSommets++;
}

void ajouterArc(ReseauTrophique *reseau, int from, int to, float poids) {
    reseau->arcs = realloc(reseau->arcs, (reseau->nbArcs + 1) * sizeof(Arc));
    reseau->arcs[reseau->nbArcs].from = from;
    reseau->arcs[reseau->nbArcs].to = to;
    reseau->arcs[reseau->nbArcs].poids = poids;
    reseau->nbArcs++;
}


void afficherReseau(ReseauTrophique *reseau) {
    printf("Reseau Trophique avec %d sommets et %d arcs:\n", reseau->nbSommets, reseau->nbArcs);
    for (int i = 0; i < reseau->nbSommets; i++) {
        printf("Sommet %d: %s, Niveau Trophique: %d\n", i, reseau->sommets[i].nom, reseau->sommets[i].niveauTrophique);
    }
    for (int i = 0; i < reseau->nbArcs; i++) {
        printf("Arc %d: de %d a %d, Poids: %.2f\n", i, reseau->arcs[i].from, reseau->arcs[i].to, reseau->arcs[i].poids);
    }
}

void lireFichierEtConstruireReseau(const char *filename, ReseauTrophique *reseau) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        perror("Erreur lors de l'ouverture du fichier");
        return;
    }

    char line[1024];
    while (fgets(line, sizeof(line), file)) {
        if (line[0] == '#' || line[0] == '\n') continue; // Ignorer les commentaires et les lignes vides
        char type;
        char nom[100];
        int niveau, from, to;
        float poids;

        if (sscanf(line, "%c, %99[^,], %d", &type, nom, &niveau) == 3 && type == 'S') {
            ajouterSommet(reseau, nom, niveau);
        } else if (sscanf(line, "%c, %d, %d, %f", &type, &from, &to, &poids) == 4 && type == 'A') {
            ajouterArc(reseau, from, to, poids);
        }
    }

    fclose(file);
}

void ecrireCSV(ReseauTrophique *reseau) {
    FILE *fpNodes = fopen("nodes.csv", "w");
    FILE *fpEdges = fopen("edges.csv", "w");

    // En-têtes pour Gephi
    fprintf(fpNodes, "Id,Label,NiveauTrophique\n");
    fprintf(fpEdges, "Source,Target,Weight\n");

    // Écrire les données des sommets
    for (int i = 0; i < reseau->nbSommets; i++) {
        fprintf(fpNodes, "%d,\"%s\",%d\n", reseau->sommets[i].id, reseau->sommets[i].nom, reseau->sommets[i].niveauTrophique);
    }

    // Écrire les données des arcs
    for (int i = 0; i < reseau->nbArcs; i++) {
        fprintf(fpEdges, "%d,%d,%.2f\n", reseau->arcs[i].from, reseau->arcs[i].to, reseau->arcs[i].poids);
    }

    fclose(fpNodes);
    fclose(fpEdges);
}



// Écrit le réseau au format DOT pour Graphviz
void ecrireDot(ReseauTrophique *reseau, const char *filename) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        perror("Erreur lors de la creation du fichier DOT");
        return;
    }

    fprintf(file, "digraph ReseauTrophique {\n");
    fprintf(file, "    node [shape=circle];\n");

    // Écrire les sommets
    for (int i = 0; i < reseau->nbSommets; i++) {
        fprintf(file, "    %d [label=\"%s\"];\n", reseau->sommets[i].id, reseau->sommets[i].nom);
    }

    // Écrire les arcs
    for (int i = 0; i < reseau->nbArcs; i++) {
        fprintf(file, "    %d -> %d [label=\"%.2f\", weight=%.2f];\n",
                reseau->arcs[i].from, reseau->arcs[i].to, reseau->arcs[i].poids, reseau->arcs[i].poids);
    }

    fprintf(file, "}\n");
    fclose(file);
}

// Supprime l'extension d'un nom de fichier
void retirerExtension(const char *filename, char *output) {
    strcpy(output, filename);
    char *dot = strrchr(output, '.');
    if (dot != NULL) *dot = '\0';
}