//
// Created by thoma on 13/11/2024.
//

#ifndef PROJET_TDG_BIBLIO_H
#define PROJET_TDG_BIBLIO_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char *nom;
    int niveauTrophique;
    int id;  // Ajout d'un identifiant pour chaque sommet
} Sommet;

typedef struct {
    int from;
    int to;
    float poids;
} Arc;

typedef struct {
    Sommet *sommets;
    Arc *arcs;
    int nbSommets;
    int nbArcs;
} ReseauTrophique;

ReseauTrophique* initReseau();
void ajouterSommet(ReseauTrophique *reseau, char *nom, int niveau);
void ajouterArc(ReseauTrophique *reseau, int from, int to, float poids) ;
void afficherReseau(ReseauTrophique *reseau);
void lireFichierEtConstruireReseau(const char *filename, ReseauTrophique *reseau);
void ecrireCSV(ReseauTrophique *reseau);
void ecrireDot(ReseauTrophique *reseau, const char *filename);
void retirerExtension(const char *filename, char *output);
#endif //PROJET_TDG_BIBLIO_H
