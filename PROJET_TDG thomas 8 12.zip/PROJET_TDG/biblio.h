//
// Created by thoma on 13/11/2024.
//

#ifndef PROJET_TDG_BIBLIO_H
#define PROJET_TDG_BIBLIO_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Structure pour un sommet (espèce)
typedef struct Sommet {
    char *nom;
    int niveauTrophique; // Niveau trophique de l'espèce
    int numero; // Numero du sommet
    int nbr_especes; // Nombre de représentant de l'espece
    struct Sommet **  successeur; // Liste des successeurs
    int nbr_succ; // Nbr de successeurs
    struct Sommet ** predecesseur; // Liste des prédecesseurs
    int nbr_pred; // Nbr de prédecesseurs
} Sommet;

// Structure pour un arc (relation alimentaire)
typedef struct Arc {
    int from; // Index du sommet de départ
    int to; // Index du sommet d'arrivée
    float poids; // Poids de l'arc, par exemple la quantité de biomasse échangée
} Arc;

// Structure pour un réseau trophique
typedef struct ReseauTrophique {
    Sommet *sommets; // Tableau dynamique de sommets
    Arc *arcs; // Tableau dynamique d'arcs
    int nbSommets; // Nombre de sommets
    int nbArcs; // Nombre d'arcs
    int hauteur_trophique; // Distance du sommet de départ au sommet concerné
    float densite; // Densité de liaison
} ReseauTrophique;

//Initialisation du réseau
ReseauTrophique* initReseau();
//Création du graphe
int lireFichierEtConstruireReseau(const char *filename, ReseauTrophique *reseau);
void ajouterSommet(ReseauTrophique *reseau, char *nom, int niveau, int nbr_espece,int numero);
void ajouterArc(ReseauTrophique *reseau, int from, int to, float poids);
//Affichage du réseau
void afficherReseau(ReseauTrophique *reseau);
void affichagePredecesseuretSuccesseur(ReseauTrophique *reseau);
//Création des tableaux predecesseurs successeurs sans algo
void PredetSucc(ReseauTrophique *reseau);
//Moteur de recherche
void moteur_de_recherche(ReseauTrophique *reseau);
//Création des fichiers pour usages externes
void ecrireCSV(ReseauTrophique *reseau);
void ecrireDot(ReseauTrophique *reseau, const char *filename);
//Fonctions pratiques
void retirerExtension(const char *filename, char *output);

#endif //PROJET_TDG_BIBLIO_H