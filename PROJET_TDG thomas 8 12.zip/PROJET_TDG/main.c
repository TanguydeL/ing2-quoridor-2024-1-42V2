#include "biblio.h"

int main() {
    const char *options[] = {"fichier.txt", "fichier1.txt", "fichier2.txt"};
    const char *noms[] = {"de la foret", "du grand nord", "de la savane"};
    int nbOptions = sizeof(options) / sizeof(options[0]);
    int choix;

    while (1) {
        printf("Choisissez le reseau trophique a analyser :\n");
        for (int i = 0; i < nbOptions; i++) {
            printf("%d : Charger le reseau %s\n", i + 1, noms[i]);
        }
        printf("%d : Quitter\n", nbOptions + 1);

        printf("Entrez votre choix (1-%d) : ", nbOptions + 1);
        scanf("%d", &choix);

        if (choix == nbOptions + 1) {
            printf("Quitter le programme.\n");
            break; // Quitter la boucle et finir le programme
        }

        if (choix < 1 || choix > nbOptions + 1) {
            printf("Choix invalide, veuillez réessayer.\n");
            continue; // Continue la boucle pour demander à nouveau
        }

        // Traitement du fichier sélectionné
        ReseauTrophique *monReseau = initReseau();
        if (lireFichierEtConstruireReseau(options[choix - 1], monReseau) == 1) {
            char baseFilename[256];
            retirerExtension(options[choix - 1], baseFilename);

            char dotFile[256], pngFile[256];
            sprintf(dotFile, "%s.dot", baseFilename);
            sprintf(pngFile, "%s.png", baseFilename);

            ecrireCSV(monReseau);
            ecrireDot(monReseau, dotFile);

            printf("Fichier DOT genere : %s\n", dotFile);

            char graphvizCommand[512];
            sprintf(graphvizCommand, "dot -Tpng %s -o %s", dotFile, pngFile);
            if (system(graphvizCommand) == 0) {
                printf("Image generee : %s\n", pngFile);
#ifdef _WIN32
                char openCommand[512];
                sprintf(openCommand, "start %s", pngFile);
                system(openCommand);
#endif
            } else {
                fprintf(stderr, "Erreur lors de la génération de l'image avec Graphviz\n");
            }

            afficherReseau(monReseau);
            moteur_de_recherche(monReseau);

            // Libération de la mémoire
            for (int i = 0; i < monReseau->nbSommets; i++) {
                free(monReseau->sommets[i].nom);
            }
            free(monReseau->sommets);
            free(monReseau->arcs);
            free(monReseau);
        } else {
            printf("Erreur lors de l'ouverture ou de la lecture du fichier.\n");
        }
    }

    return 0;
}
