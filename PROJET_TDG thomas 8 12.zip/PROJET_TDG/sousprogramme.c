
#include "biblio.h"

//Initialisation du réseau
ReseauTrophique* initReseau() {
    ReseauTrophique *reseau = malloc(sizeof(ReseauTrophique));
    //Initialisation des composantes du réseau
    reseau->sommets = NULL;
    reseau->arcs = NULL;
    reseau->nbSommets = 0;
    reseau->nbArcs = 0;
    reseau->hauteur_trophique = 0;
    return reseau;
}

//Création d'un sommet
void ajouterSommet(ReseauTrophique *reseau, char *nom, int niveau, int nbr_espece,int numero) {
    reseau->sommets = realloc(reseau->sommets, (reseau->nbSommets + 1) * sizeof(Sommet));
    //Initialisation des composantes du sommet
    reseau->sommets[reseau->nbSommets].nom = strdup(nom); // Utilisation de strdup pour copier le nom
    reseau->sommets[reseau->nbSommets].niveauTrophique = niveau;
    reseau->sommets[reseau->nbSommets].nbr_especes = nbr_espece;
    reseau->sommets[reseau->nbSommets].numero = numero;
    reseau->sommets[reseau->nbSommets].predecesseur = NULL;
    reseau->sommets[reseau->nbSommets].successeur = NULL;
    reseau->sommets[reseau->nbSommets].nbr_pred = 0;
    reseau->sommets[reseau->nbSommets].nbr_succ = 0;
    //Détermination de la hauteur trophique du réseau
    if(reseau->sommets[reseau->nbSommets].niveauTrophique > reseau->hauteur_trophique) {
        reseau->hauteur_trophique = reseau->sommets[reseau->nbSommets].niveauTrophique;
    }
    //Incrémentation du nombre de sommets
    reseau->nbSommets++;
}

//Création d'un arc
void ajouterArc(ReseauTrophique *reseau, int from, int to, float poids) {
    reseau->arcs = realloc(reseau->arcs, (reseau->nbArcs + 1) * sizeof(Arc));
    //Initialisation des composantes de l'arc
    reseau->arcs[reseau->nbArcs].from = from;
    reseau->arcs[reseau->nbArcs].to = to;
    reseau->arcs[reseau->nbArcs].poids = poids;
    //Incrémentation du nombre d'arcs
    reseau->nbArcs++;
}

//Création des tableaux de pred et de succ pour chaque sommet ( sans algo )
void PredetSucc(ReseauTrophique *reseau) {
    //Boucle des arcs
    for (int i = 0; i < reseau->nbArcs; i++) {
        //Récupération du point de départ et du point d'arrivé de chaque arc
        int from = reseau->arcs[i].from;
        int to =  reseau->arcs[i].to;
        //Boucle de sommets
        for(int j = 0; j < reseau->nbSommets; j++) {
            //Si le sommet est le point de départ d'un arc
            if(reseau->sommets[j].numero == from) {
                //Boucle de sommets
                for(int k = 0; k < reseau->nbSommets; k++) {
                    //Si le sommet est le point d'arrivé de l'arc
                    if(reseau->sommets[k].numero == to) {
                        // sommet j est le predecesseur de sommet k (allocation, ajout dans le tableau, incrémentation)
                        reseau->sommets[k].predecesseur = realloc(reseau->sommets[k].predecesseur, (reseau->sommets[k].nbr_pred + 1) * sizeof(Sommet*));
                        reseau->sommets[k].predecesseur[reseau->sommets[k].nbr_pred] = &reseau->sommets[j];
                        reseau->sommets[k].nbr_pred++;
                        // sommet k est le successeur de sommet j (allocation, ajout dans le tableau, incrémentation)
                        reseau->sommets[j].successeur = realloc(reseau->sommets[j].successeur, (reseau->sommets[j].nbr_succ + 1) * sizeof(Sommet*));
                        reseau->sommets[j].successeur[reseau->sommets[j].nbr_succ] = &reseau->sommets[k];
                        reseau->sommets[j].nbr_succ++;
                    }
                }
            }
        }
    }
}

//Affichage du réseau
void afficherReseau(ReseauTrophique *reseau) {
    //Calcule de la densité du réseau
    float max_liens = 0;
    max_liens = reseau->nbSommets * (reseau->nbSommets - 1);
    reseau->densite = (float)reseau->nbArcs/max_liens;
    //Affichage des informations relatives au réseau
    printf("Reseau Trophique avec %d sommets, %d arcs et de hauteur throphique : %d et de densité : %0.3f\n",
           reseau->nbSommets, reseau->nbArcs,reseau->hauteur_trophique,reseau->densite);
    //Affichage des sommets du réseau
    printf("Liste des sommets : \n");
    for (int i = 0; i < reseau->nbSommets; i++) {
        printf("Sommet %d: %s, Niveau Trophique: %d,Quantité: %d\n", i, reseau->sommets[i].nom, reseau->sommets[i].niveauTrophique,reseau->sommets[i].nbr_especes);
    }
    //Affichage des aretes du réseau
    printf("Liste des aretes : \n");
    for (int i = 0; i < reseau->nbArcs; i++) {
        printf("Arc %d: de %d a %d, Poids: %.2f\n", i, reseau->arcs[i].from, reseau->arcs[i].to, reseau->arcs[i].poids);
    }
    //Affichage des predecesseurs et des successeurs
    affichagePredecesseuretSuccesseur(reseau);
}

//Affichage des predecesseurs et des successeurs
void affichagePredecesseuretSuccesseur(ReseauTrophique *reseau) {
    //Création des tableaux des predécesseurs et des successeurs
    PredetSucc(reseau);
    //Boucle de sommets
    for(int i = 0;i < reseau->nbSommets; i++) {
        //Affichage des predecesseurs du sommet
        printf("Les predecesseurs de %s sont : \n", reseau->sommets[i].nom);
        //S'il n'a aucun predecesseurs
        if(reseau->sommets[i].nbr_pred == 0) {
            printf("Aucun\n");
        }
            //S'il en a
        else {
            for (int j = 0; j < reseau->sommets[i].nbr_pred; j++) {
                printf("%s\n", reseau->sommets[i].predecesseur[j]->nom);
            }
        }
        //Affichage des successeurs du sommet
        printf("Les successeurs de %s sont : \n", reseau->sommets[i].nom);
        //S'il n'a aucun successeur
        if(reseau->sommets[i].nbr_succ == 0) {
            printf("Aucun\n");
        }
            //S'il en a
        else {
            for (int j = 0; j < reseau->sommets[i].nbr_succ; j++) {
                printf("%s\n", reseau->sommets[i].successeur[j]->nom);
            }
        }
    }
}

//Lecture du fichier texte
int lireFichierEtConstruireReseau(const char *filename, ReseauTrophique *reseau) {
    //Ouverture du fichier en mode lecture
    FILE *file = fopen(filename, "r");
    //Vérification d'existence du fichier
    if (file == NULL) {
        perror("Erreur lors de l'ouverture du fichier");
        return 0;
    }

    char line[1024];
    while (fgets(line, sizeof(line), file)) {
        if (line[0] == '#' || line[0] == '\n') continue; // Ignorer les commentaires et les lignes vides
        //Initialisation des variables
        char type;
        char nom[100];
        int niveau, from, to, nbr_espece, numero;
        float poids;
        //Lecture du fichier et association à un sommet ou à un arc
        if (sscanf(line, "%c, %99[^,], %d, %d, %d", &type, nom, &numero, &niveau, &nbr_espece) == 5 && type == 'S') {
            ajouterSommet(reseau, nom, niveau, nbr_espece, numero);
        } else if (sscanf(line, "%c, %d, %d, %f", &type, &from, &to, &poids) == 4 && type == 'A') {
            ajouterArc(reseau, from, to, poids);
        }
    }
    return 1;
    //Fermeture du fichier
    fclose(file);
}

//Moteur de recherche en fontion du nom, nbr pred et nbr succ
void moteur_de_recherche(ReseauTrophique *reseau) {
    //Initialisation des variables
    int choix;
    int nbr;
    char nom[100];
    int verification = 0;
    int sommet = 0;
    int taille = 0;
    int tab[taille];
    //Boucle de choix du menu
    do {
        printf("Selon quelle information voulez vous faire votre recherche ?\n"
               "1 : nom\n"
               "2 : nbr de predecesseurs\n"
               "3 : nbr de successeurs\n"
               "4 : QUITTER\n");
        scanf("%d",&choix);
        switch (choix) {
            //Recherche en fonction du nom
            case 1:
                printf("Quel est le nom du sommet que vous rechercher ? (remplacer les espaces par _)\n");
                scanf("%s", nom);
                //Recherche du sommet avec vérification d'existence
                for(int i = 0; i < reseau->nbSommets; i++) {
                    if(strcmp(reseau->sommets[i].nom, nom) == 0) {
                        verification = 1;
                        sommet = i;
                    }
                }
                //Affichage du sommet et de l'ensemble de ses informations
                if(verification == 1) {
                    printf("Votre sommet est : %s\n"
                           "il y a %d predecesseur(s) et %d successeur(s)\n"
                           "il est de niveau trophique %d\n"
                           "et cette espece compte %d membres\n",
                           reseau->sommets[sommet].nom,reseau->sommets[sommet].nbr_pred,reseau->sommets[sommet].nbr_succ,reseau->sommets[sommet].niveauTrophique,reseau->sommets[sommet].nbr_especes);
                }
                    //Si inexistence
                else {
                    printf("Votre sommet n'existe pas\n");
                }
                //Remise à 0
                verification = 0;
                break;
                //Rechercher en fonction du nombre de predecesseurs
            case 2:
                printf("Combien de predecesseurs doivent avoir vos sommets ?\n");
                scanf("%d",&nbr);
                //Recherche des sommets avec vérification d'existence
                for(int i = 0; i < reseau->nbSommets; i++) {
                    if(reseau->sommets[i].nbr_pred == nbr) {
                        verification = 1;
                        tab[taille] = i;
                        taille++;
                    }
                }
                //Affichage de la liste des sommets vérifiant le nombre de predecesseurs voulu
                if(verification == 1) {
                    for(int i = 0; i < taille; i++) {
                        for(int j = 0; j < reseau->nbSommets; j++) {
                            if(tab[i] == j) {
                                printf("le sommet : %s correspond\n",reseau->sommets[j].nom);
                            }
                        }
                    }
                }
                    //Si inexistence
                else {
                    printf("Aucun sommet ne correspond\n");
                }
                //Remise à 0
                nbr = 0;
                verification = 0;
                break;
                //Recherche en fonction du nombre de successeurs
            case 3:
                printf("Combien de successeurs doivent avoir vos sommets ?\n");
                scanf("%d",&nbr);
                //Recherche des sommets avec vérification d'existence
                for(int i = 0; i < reseau->nbSommets; i++) {
                    if(reseau->sommets[i].nbr_succ == nbr) {
                        verification = 1;
                        tab[taille] = i;
                        taille++;
                    }
                }
                //Affichage de la liste des sommets vérifiant le nombre de successeurs voulu
                if(verification == 1) {
                    for(int i = 0; i < taille; i++) {
                        for(int j = 0; j < reseau->nbSommets; j++) {
                            if(tab[i] == j) {
                                printf("le sommet : %s correspond\n",reseau->sommets[j].nom);
                            }
                        }
                    }
                }
                    //Si inexistence
                else {
                    printf("Aucun sommet ne correspond\n");
                }
                //Remise à 0
                nbr = 0;
                verification = 0;
                break;
        }
    }while(choix != 4);
}

//Ecrire le réseau au format CSV
void ecrireCSV(ReseauTrophique *reseau) {
    FILE *fpNodes = fopen("nodes.csv", "w");
    FILE *fpEdges = fopen("edges.csv", "w");

    // En-têtes pour Gephi
    fprintf(fpNodes, "Id,Label,NiveauTrophique\n");
    fprintf(fpEdges, "Source,Target,Weight\n");

    // Écrire les données des sommets
    for (int i = 0; i < reseau->nbSommets; i++) {
        fprintf(fpNodes, "%d,\"%s\",%d\n", reseau->sommets[i].numero, reseau->sommets[i].nom, reseau->sommets[i].niveauTrophique);
    }

    // Écrire les données des arcs
    for (int i = 0; i < reseau->nbArcs; i++) {
        fprintf(fpEdges, "%d,%d,%.2f\n", reseau->arcs[i].from, reseau->arcs[i].to, reseau->arcs[i].poids);
    }

    fclose(fpNodes);
    fclose(fpEdges);
}

//Ecrire le réseau au format DOT pour Graphviz
void ecrireDot(ReseauTrophique *reseau, const char *filename) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        perror("Erreur lors de la création du fichier DOT");
        return;
    }

    fprintf(file, "digraph ReseauTrophique {\n");
    fprintf(file, "    node [shape=none, margin=0.4, fontsize=18];\n");

    for (int i = 0; i < reseau->nbSommets; i++) {
        char imgPath[256];
        sprintf(imgPath, "animaux/%s.png", reseau->sommets[i].nom);
        fprintf(file, "    %d [image=\"%s\", label=\"\\n%s\\nNiveau: %d\\nEspèces: %d\", labelloc=b, width=\".25\", height=\".25\"];\n",
                reseau->sommets[i].numero, imgPath, reseau->sommets[i].nom, reseau->sommets[i].niveauTrophique, reseau->sommets[i].nbr_especes);
    }

    // Set penwidth to increase the thickness of the arrows
    for (int i = 0; i < reseau->nbArcs; i++) {
        fprintf(file, "    %d -> %d [label=\"%.2f\", weight=\"%.2f\", penwidth=16.0, fontsize=60];\n",
                reseau->arcs[i].from, reseau->arcs[i].to, reseau->arcs[i].poids, reseau->arcs[i].poids);
    }

    fprintf(file, "}\n");
    fclose(file);
}



//Supprimer l'extension d'un nom de fichier
void retirerExtension(const char *filename, char *output) {
    strcpy(output, filename);
    char *dot = strrchr(output, '.');
    if (dot != NULL) *dot = '\0';
}