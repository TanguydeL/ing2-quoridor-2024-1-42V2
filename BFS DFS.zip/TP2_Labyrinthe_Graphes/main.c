
#include "Graphe.h"

/* affichage des successeurs du sommet num*/
void afficher_successeurs(pSommet * sommet, int num)
{

    printf(" sommet %d :\n",num);

    pArc arc=sommet[num]->arc;

    while(arc!=NULL)
    {
        printf("%d ",arc->sommet);
        arc=arc->arc_suivant;
    }

}

// Ajouter l'arête entre les sommets s1 et s2 du graphe
pSommet* CreerArete(pSommet* sommet,int s1,int s2)
{
    if(sommet[s1]->arc==NULL)
    {
        pArc Newarc=(pArc)malloc(sizeof(struct Arc));
        Newarc->sommet=s2;
        Newarc->arc_suivant=NULL;
        sommet[s1]->arc=Newarc;
        return sommet;
    }

    else
    {
        pArc temp=sommet[s1]->arc;
        while( !(temp->arc_suivant==NULL))
        {
            temp=temp->arc_suivant;
        }
        pArc Newarc=(pArc)malloc(sizeof(struct Arc));
        Newarc->sommet=s2;
        Newarc->arc_suivant=NULL;

        if(temp->sommet>s2)
        {
            Newarc->arc_suivant=temp->arc_suivant;
            Newarc->sommet=temp->sommet;
            temp->sommet=s2;
            temp->arc_suivant=Newarc;
            return sommet;
        }

        temp->arc_suivant=Newarc;
        return sommet;
    }
}

// créer le graphe
Graphe* CreerGraphe(int ordre)
{
    Graphe * Newgraphe=(Graphe*)malloc(sizeof(Graphe));
    Newgraphe->pSommet = (pSommet*)malloc(ordre*sizeof(pSommet));

    for(int i=0; i<ordre; i++)
    {
        Newgraphe->pSommet[i]=(pSommet)malloc(sizeof(struct Sommet));
        Newgraphe->pSommet[i]->valeur=i;
        Newgraphe->pSommet[i]->arc=NULL;
    }
    return Newgraphe;
}


/* La construction du réseau peut se faire à partir d'un fichier dont le nom est passé en paramètre
Le fichier contient : ordre, taille,orientation (0 ou 1)et liste des arcs */
Graphe * lire_graphe(char * nomFichier)
{
    Graphe* graphe;
    FILE * ifs = fopen(nomFichier,"r");
    int taille, orientation, ordre, s1, s2;

    if (!ifs)
    {
        printf("Erreur de lecture fichier\n");
        exit(-1);
    }

    fscanf(ifs,"%d",&ordre);
    ordre = ordre +2;
    graphe=CreerGraphe(ordre); // créer le graphe d'ordre sommets

    fscanf(ifs,"%d",&taille);
    fscanf(ifs,"%d",&orientation);

    graphe->orientation=orientation;
    graphe->ordre=ordre;

    // créer les arêtes du graphe
    for (int i=0; i<taille; ++i)
    {
        fscanf(ifs,"%d%d",&s1,&s2);
        graphe->pSommet=CreerArete(graphe->pSommet, s1, s2);

        if(!orientation)
            graphe->pSommet=CreerArete(graphe->pSommet, s2, s1);
    }

    return graphe;
}

/*affichage du graphe avec les successeurs de chaque sommet */
void graphe_afficher(Graphe* graphe)
{
    printf("graphe\n");

    if(graphe->orientation)
        printf("oriente\n");

    else
        printf("non oriente\n");

    printf("ordre = %d\n",graphe->ordre);

    printf("listes d'adjacence :\n");

    for (int i=0; i<graphe->ordre; i++)
    {
        afficher_successeurs(graphe->pSommet, i);
        printf("\n");
    }

}



void BFS(pSommet* sommet, int start, int ordre) {
    int *visited = (int*)malloc(ordre * sizeof(int));


    for(int i = 2; i < ordre; i++) {
        visited[i] = 0;  // Initialiser tous les sommets comme non visités
    }

    int *queue = (int*)malloc(ordre * sizeof(int));
    int front = 0, rear = 0;

    visited[start] = 1;  // Marquer le sommet initial comme visité
    queue[rear++] = start;  // L'ajouter à la file

    printf("Parcours BFS à partir du sommet %d : ", start);

    while (front != rear) {
        int current = queue[front++];  // Extraire le sommet de la file
        printf("%d ", current);

        pArc arc = sommet[current]->arc;  // Obtenir les successeurs
        while(arc != NULL) {
            int adj = arc->sommet;
            if (!visited[adj]) {
                visited[adj] = 1;  // Marquer le sommet adj comme visité
                queue[rear++] = adj;  // L'ajouter à la file
            }
            arc = arc->arc_suivant;
        }
    }
    printf("\n");
    free(queue);
    free(visited);
}

void DFS(pSommet* sommet, int current, int *visited) {
    visited[current] = 1;  // Marquer le sommet comme visité
    printf("%d ", current);

    pArc arc = sommet[current]->arc;  // Obtenir les successeurs
    while(arc != NULL) {
        int adj = arc->sommet;
        if (!visited[adj]) {
            DFS(sommet, adj, visited);  // Appel récursif pour le sommet adjacent
        }
        arc = arc->arc_suivant;
    }
}

void DFS_start(pSommet* sommet, int start, int ordre) {
    int *visited = (int*)malloc(ordre * sizeof(int));
    for(int i = 0; i < ordre; i++) {
        visited[i] = 0;  // Initialiser tous les sommets comme non visités
    }

    printf("Parcours DFS à partir du sommet %d : ", start);
    DFS(sommet, start, visited);  // Appel de la fonction DFS
    printf("\n");
    free(visited);
}

// Fonction pour afficher un chemin
void afficher_chemin(int chemin[], int taille) {
    for (int i = 0; i < taille; i++) {
        printf("%d ", chemin[i]);
    }
    printf("\n");
}

// Fonction DFS modifiée pour suivre et afficher les chemins
void DFS_paths(pSommet* sommets, int current, int *visited, int chemin[], int profondeur, int ordre) {
    visited[current] = 1;
    chemin[profondeur] = current;  // Ajouter le sommet courant au chemin
    profondeur++;

    pArc arc = sommets[current]->arc;
    int est_feuille = 1;  // Indicateur de sommet feuille (pas de successeurs non visités)

    while (arc != NULL) {
        int adj = arc->sommet;
        if (!visited[adj]) {
            est_feuille = 0;
            DFS_paths(sommets, adj, visited, chemin, profondeur, ordre);  // Continuer en profondeur
        }
        arc = arc->arc_suivant;
    }

    // Si c'est un sommet feuille ou tous les sommets sont visités, afficher le chemin parcouru
    if (est_feuille || profondeur == ordre) {
        afficher_chemin(chemin, profondeur);
    }

    visited[current] = 0;  // Backtracking pour explorer d'autres chemins
}

//Fonction pour trouver et afficher tous les chemins depuis un sommet
void trouver_chemins_DFS(pSommet* sommets, int start, int ordre) {
    int *visited = (int*)malloc(ordre * sizeof(int));
    int *chemin = (int*)malloc(ordre * sizeof(int));  // Tableau pour stocker le chemin courant

    for (int i = 0; i < ordre; i++) {
        visited[i] = 0;  // Initialiser tous les sommets comme non visités
    }

    printf("Chemins possibles depuis le sommet %d :\n", start);
    DFS_paths(sommets, start, visited, chemin, 0, ordre);  // Démarrer DFS avec le sommet initial

    free(visited);
    free(chemin);
}

// Fonction pour trouver et afficher les composantes connexes
void recherche_composantes_connexes(pSommet* sommet, int ordre) {
    int *visited = (int*)malloc(ordre * sizeof(int));
    for (int i = 0; i < ordre; i++) {
        visited[i] = 0;  // Initialiser tous les sommets comme non visités
    }

    int composante_num = 1;

    // Parcourir tous les sommets
    for (int i = 2; i < ordre; i++) {
        if (!visited[i]) {  // Si le sommet n'a pas été visité
            printf("Composante connexe %d : ", composante_num);
            DFS(sommet, i, visited);  // Lancer un DFS pour marquer tous les sommets de cette composante
            printf("\n");
            composante_num++;
        }
    }

    free(visited);
}



int main()
{
    Graphe * g;
    char nom_fichier[50];
    int sommet_initial;

    printf("entrer le nom du fichier du labyrinthe:");
    gets(nom_fichier);

    g = lire_graphe(nom_fichier);

    /// saisie du numéro du sommet initial pour lancer un BFS puis un DFS
    printf("numero du sommet initial : ");
    scanf("%d", &sommet_initial);

    /// afficher le graphe
    graphe_afficher(g);

    /// Exécuter BFS et DFS
    BFS(g->pSommet, sommet_initial, g->ordre);
    DFS_start(g->pSommet, sommet_initial, g->ordre);

    /// Exécuter DFS pour afficher tous les chemins possibles
    trouver_chemins_DFS(g->pSommet, sommet_initial, g->ordre);

    /// Rechercher et afficher les composantes connexes
    printf("\nRecherche des composantes connexes :\n");
    recherche_composantes_connexes(g->pSommet, g->ordre);

    return 0;
}