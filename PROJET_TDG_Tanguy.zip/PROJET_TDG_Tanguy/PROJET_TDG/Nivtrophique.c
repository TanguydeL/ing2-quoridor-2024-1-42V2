#include "biblio.h"

#include "biblio.h"

// Fonction pour calculer les niveaux trophiques
void recherche_niv_trophique(ReseauTrophique* reseau, int* niveaux, char roles[TAILLE_MAX][50]) {
    for (int i = 0; i < reseau->nbSommets; i++) niveaux[i] = -1; // Initialiser les niveaux a -1
    for (int i = 0; i < reseau->nbSommets; i++) {
        for (int j = 0; j < reseau->nbArcs; j++) {
            int source = reseau->arcs[j].from;
            int cible = reseau->arcs[j].to;
            if (niveaux[source] == -1) niveaux[source] = 0; // Producteurs au niveau 0
            if (niveaux[source] + 1 > niveaux[cible]) niveaux[cible] = niveaux[source] + 1;
        }
    }

    // Attribuer les roles trophiques en fonction des niveaux
    for (int i = 0; i < reseau->nbSommets; i++) {
        if (niveaux[i] == 0) {
            strcpy(roles[i], "Producteur");
        } else if (niveaux[i] == 1) {
            strcpy(roles[i], "Consommateur primaire");
        } else if (niveaux[i] == 2) {
            strcpy(roles[i], "Consommateur secondaire");
        } else if (niveaux[i] == 3) {
            strcpy(roles[i], "Consommateur tertiaire");
        }else if (niveaux[i] == 4) {
            strcpy(roles[i], "Consommateur quaternaires");
        }else if (niveaux[i] == 5) {
            strcpy(roles[i], "Consommateur quintenaire");
        }else if (niveaux[i] == 6) {
            strcpy(roles[i], "Consommateur sixenaire");
        } else if (niveaux[i] == 7) {
            strcpy(roles[i], "Consommateur septenaire");
        } else {
            strcpy(roles[i], "Non connexe");
        }
    }
}

void recherche_chaine_alimentaire(ReseauTrophique* reseau) {

}
