#include "biblio.h"

//Ecrire le réseau au format CSV
void ecrireCSV(ReseauTrophique *reseau) {
    FILE *fpNodes = fopen("nodes.csv", "w");
    FILE *fpEdges = fopen("edges.csv", "w");

    // En-têtes pour Gephi
    fprintf(fpNodes, "Id,Label,NiveauTrophique\n");
    fprintf(fpEdges, "Source,Target,Weight\n");

    // Écrire les données des sommets
    for (int i = 0; i < reseau->nbSommets; i++) {
        fprintf(fpNodes, "%d,\"%s\",%d\n", reseau->sommets[i].numero, reseau->sommets[i].nom, reseau->sommets[i].niveauTrophique);
    }

    // Écrire les données des arcs
    for (int i = 0; i < reseau->nbArcs; i++) {
        fprintf(fpEdges, "%d,%d,%.2f\n", reseau->arcs[i].from, reseau->arcs[i].to, reseau->arcs[i].poids);
    }

    fclose(fpNodes);
    fclose(fpEdges);
}

//Ecrire le réseau au format DOT pour Graphviz
void ecrireDot(ReseauTrophique *reseau, const char *filename) {
    FILE *file = fopen(filename, "w");
    if (file == NULL) {
        perror("Erreur lors de la creation du fichier DOT");
        return;
    }

    fprintf(file, "digraph ReseauTrophique {\n");
    fprintf(file, "    node [shape=circle];\n");

    // Écrire les sommets
    for (int i = 0; i < reseau->nbSommets; i++) {
        fprintf(file, "    %d [label=\"%s\"];\n", reseau->sommets[i].numero, reseau->sommets[i].nom);
    }

    // Écrire les arcs
    for (int i = 0; i < reseau->nbArcs; i++) {
        fprintf(file, "    %d -> %d [label=\"%.2f\", weight=%.2f];\n",
                reseau->arcs[i].from, reseau->arcs[i].to, reseau->arcs[i].poids, reseau->arcs[i].poids);
    }

    fprintf(file, "}\n");
    fclose(file);
}

//Supprimer l'extension d'un nom de fichier
void retirerExtension(const char *filename, char *output) {
    strcpy(output, filename);
    char *dot = strrchr(output, '.');
    if (dot != NULL) *dot = '\0';
}