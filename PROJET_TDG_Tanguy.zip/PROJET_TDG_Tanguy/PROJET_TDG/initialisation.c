#include "biblio.h"

//Initialisation du réseau
ReseauTrophique* initReseau() {
    ReseauTrophique *reseau = malloc(sizeof(ReseauTrophique));
    //Initialisation des composantes du réseau
    reseau->sommets = NULL;
    reseau->arcs = NULL;
    reseau->nbSommets = 0;
    reseau->nbArcs = 0;
    reseau->hauteur_trophique = 0;
    return reseau;
}

//Création d'un sommet
void ajouterSommet(ReseauTrophique *reseau, char *nom, int niveau, int nbr_espece,int numero) {
    reseau->sommets = realloc(reseau->sommets, (reseau->nbSommets + 1) * sizeof(Sommet));
    //Initialisation des composantes du sommet
    reseau->sommets[reseau->nbSommets].nom = strdup(nom); // Utilisation de strdup pour copier le nom
    reseau->sommets[reseau->nbSommets].niveauTrophique = 0;
    reseau->sommets[reseau->nbSommets].nbr_especes = nbr_espece;
    reseau->sommets[reseau->nbSommets].numero = numero;
    reseau->sommets[reseau->nbSommets].predecesseur = NULL;
    reseau->sommets[reseau->nbSommets].successeur = NULL;
    reseau->sommets[reseau->nbSommets].nbr_pred = 0;
    reseau->sommets[reseau->nbSommets].nbr_succ = 0;
    //Incrémentation du nombre de sommets
    reseau->nbSommets++;
}

//Création d'un arc
void ajouterArc(ReseauTrophique *reseau, int from, int to, float poids) {
    reseau->arcs = realloc(reseau->arcs, (reseau->nbArcs + 1) * sizeof(Arc));
    //Initialisation des composantes de l'arc
    reseau->arcs[reseau->nbArcs].from = from;
    reseau->arcs[reseau->nbArcs].to = to;
    reseau->arcs[reseau->nbArcs].poids = poids;
    //Incrémentation du nombre d'arcs
    reseau->nbArcs++;
}

//Lecture du fichier texte
int lireFichierEtConstruireReseau(const char *filename, ReseauTrophique *reseau) {
    //Ouverture du fichier en mode lecture
    FILE *file = fopen(filename, "r");
    //Vérification d'existence du fichier
    if (file == NULL) {
        perror("Erreur lors de l'ouverture du fichier");
        return 0;
    }

    char line[1024];
    while (fgets(line, sizeof(line), file)) {
        if (line[0] == '#' || line[0] == '\n') continue; // Ignorer les commentaires et les lignes vides
        //Initialisation des variables
        char type;
        char nom[100];
        int niveau, from, to, nbr_espece, numero;
        float poids;
        //Lecture du fichier et association à un sommet ou à un arc
        if (sscanf(line, "%c, %99[^,], %d, %d, %d", &type, nom, &numero, &niveau, &nbr_espece) == 5 && type == 'S') {
            ajouterSommet(reseau, nom, niveau, nbr_espece, numero);
        } else if (sscanf(line, "%c, %d, %d, %f", &type, &from, &to, &poids) == 4 && type == 'A') {
            ajouterArc(reseau, from, to, poids);
        }
    }
    return 1;
    //Fermeture du fichier
    fclose(file);
}
