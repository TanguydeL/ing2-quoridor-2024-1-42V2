#include "biblio.h"
#include "dfs.h"

int main() {
    //Initialisation des variables
    char filename[256];
    char baseFilename[256];
    //boucle pour changer de fichier à volonté
    do {
        ReseauTrophique *monReseau = initReseau();
        //Récupération du nom de fichier à ouvrir
        printf("Entrez le nom du fichier du reseau trophique : ");
        scanf("%255s", filename); // Lire le nom du fichier avec une taille maximale de 255 caractères

        int validiation = lireFichierEtConstruireReseau(filename, monReseau);//Existence du fichier
        //S oui
        if(validiation == 1) {
            // Supprimer l'extension pour générer les fichiers avec le même nom de base
            retirerExtension(filename, baseFilename);
            //Initialisation des noms de fichiers
            char dotFile[256];
            char pngFile[256];
            sprintf(dotFile, "%s.dot", baseFilename);
            sprintf(pngFile, "%s.png", baseFilename);
            //Création des fichiers pour usages externes
            ecrireCSV(monReseau);
            ecrireDot(monReseau, dotFile);

            printf("Fichier DOT genere : %s\n", dotFile);

            // Génération de l'image et ouverture
            char graphvizCommand[512];
            sprintf(graphvizCommand, "dot -Tpng %s -o %s", dotFile, pngFile);

            int retCode = system(graphvizCommand);
            if (retCode == 0) {
                printf("Image generee : %s\n", pngFile);
#ifdef _WIN32
                char openCommand[512];
                sprintf(openCommand, "start %s", pngFile);
                system(openCommand);
#endif
            } else {
                fprintf(stderr, "Erreur lors de la génération de l'image avec Graphviz\n");
            }
            //Affichage du réseau
            afficherReseau(monReseau);

            //chercher les niv trophique
            afficher_niveaux_trophiques(monReseau);

            //Recherche de sommets selon certains critères dans le réseau
            moteur_de_recherche(monReseau);

            // Libération de la mémoire
            for (int i = 0; i < monReseau->nbSommets; i++) {
                free(monReseau->sommets[i].nom);
            }
            free(monReseau->sommets);
            free(monReseau->arcs);
            free(monReseau);
        }
    }while(filename != "quitter");
    return 0;
}
