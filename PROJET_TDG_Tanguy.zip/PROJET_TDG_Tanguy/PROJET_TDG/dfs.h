#ifndef DFS_H
#define DFS_H
#include <stdio.h>
#include <stdlib.h>

#define MAX_NOEUDS 100

// Structure pour représenter un sommet
typedef struct Noeud {
    int sommet;
    struct Noeud* suivant;
    int id;                         // Identifiant du sommet
    int* positions;                 // Les positions du sommet dans les chemins DFS
    int nbPositions;                // Nombre de positions enregistrées
} Noeud;

// Structure pour représenter un graphe
typedef struct Graphe {
    int nombreSommets;
    Noeud* listesAdjacence;        // Pointeur vers un tableau de listes d'adjacence
    Noeud* sommets;                // Pointeur vers un tableau de sommets
    bool* visite;                   // Tableau dynamique de sommets visités
} Graphe;

Noeud* creerNoeud(int sommet);
Graphe* creerGraphe(int sommets);
void ajouterArete(Graphe* graphe, int source, int destination);
void ajouterPosition(Graphe* graphe, int sommet, int position);
void afficherPositions(Graphe* graphe);
void parcoursProfondeur(Graphe* graphe, int debut, int fin, int chemin[], int indiceChemin);
int comparer(const void* a, const void* b);
int* trierEtSupprimerDoublons(int* tableau, int taille, int* nouvelleTaille);
void tri_init(Graphe* graphe);
#endif //DFS_H
