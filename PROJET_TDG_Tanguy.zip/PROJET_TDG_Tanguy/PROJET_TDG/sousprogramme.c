#include "biblio.h"

//Création des tableaux de pred et de succ pour chaque sommet ( sans algo )
void PredetSucc(ReseauTrophique *reseau) {
    //Boucle des arcs
    for (int i = 0; i < reseau->nbArcs; i++) {
        //Récupération du point de départ et du point d'arrivé de chaque arc
        int from = reseau->arcs[i].from;
        int to =  reseau->arcs[i].to;
        //Boucle de sommets
        for(int j = 0; j < reseau->nbSommets; j++) {
            //Si le sommet est le point de départ d'un arc
            if(reseau->sommets[j].numero == from) {
                //Boucle de sommets
                for(int k = 0; k < reseau->nbSommets; k++) {
                    //Si le sommet est le point d'arrivé de l'arc
                    if(reseau->sommets[k].numero == to) {
                        // sommet j est le predecesseur de sommet k (allocation, ajout dans le tableau, incrémentation)
                        reseau->sommets[k].predecesseur = realloc(reseau->sommets[k].predecesseur, (reseau->sommets[k].nbr_pred + 1) * sizeof(Sommet*));
                        reseau->sommets[k].predecesseur[reseau->sommets[k].nbr_pred] = &reseau->sommets[j];
                        reseau->sommets[k].nbr_pred++;
                        // sommet k est le successeur de sommet j (allocation, ajout dans le tableau, incrémentation)
                        reseau->sommets[j].successeur = realloc(reseau->sommets[j].successeur, (reseau->sommets[j].nbr_succ + 1) * sizeof(Sommet*));
                        reseau->sommets[j].successeur[reseau->sommets[j].nbr_succ] = &reseau->sommets[k];
                        reseau->sommets[j].nbr_succ++;
                    }
                }
            }
        }
    }
}

// Fonction pour calculer la centralité d'intermédiarité
void calculer_centralite_intermediaire(ReseauTrophique *reseau, float *centralite) {
    int i, j, k;
    int nbSommets = reseau->nbSommets;

    // Initialiser le tableau de centralité à 0
    for (i = 0; i < nbSommets; i++) {
        centralite[i] = 0.0;
    }

    // Parcourir tous les sommets comme source et destination
    for (i = 0; i < nbSommets; i++) {
        for (j = 0; j < nbSommets; j++) {
            if (i == j) continue; // Ignorer les chemins vers soi-même

            // Initialisation des structures pour BFS
            int *niveau = (int *)malloc(nbSommets * sizeof(int));
            int *chemins = (int *)malloc(nbSommets * sizeof(int));
            float *delta = (float *)malloc(nbSommets * sizeof(float));
            Sommet **pile = (Sommet **)malloc(nbSommets * sizeof(Sommet *));
            int pileIndex = 0;

            for (k = 0; k < nbSommets; k++) {
                niveau[k] = -1;   // Non visité
                chemins[k] = 0;   // Pas de chemin encore
                delta[k] = 0.0;   // Pas de dépendance
            }

            // BFS pour trouver les plus courts chemins
            niveau[i] = 0;  // Niveau de la source
            chemins[i] = 1; // Un chemin à la source
            pile[pileIndex++] = &reseau->sommets[i]; // Ajouter la source à la pile

            for (int p = 0; p < pileIndex; p++) {
                Sommet *sommet = pile[p];
                int numSommet = sommet->numero;

                for (k = 0; k < sommet->nbr_succ; k++) {
                    Sommet *successeur = sommet->successeur[k];
                    int numSuccesseur = successeur->numero;

                    if (niveau[numSuccesseur] == -1) { // Premier passage
                        niveau[numSuccesseur] = niveau[numSommet] + 1;
                        pile[pileIndex++] = successeur;
                    }
                    if (niveau[numSuccesseur] == niveau[numSommet] + 1) {
                        chemins[numSuccesseur] += chemins[numSommet];
                    }
                }
            }

            // Calculer la dépendance en inversant la pile
            for (int p = pileIndex - 1; p >= 0; p--) {
                Sommet *sommet = pile[p];
                int numSommet = sommet->numero;

                for (k = 0; k < sommet->nbr_succ; k++) {
                    Sommet *successeur = sommet->successeur[k];
                    int numSuccesseur = successeur->numero;

                    if (niveau[numSuccesseur] == niveau[numSommet] + 1) {
                        delta[numSommet] += (float)chemins[numSommet] / chemins[numSuccesseur] * (1.0 + delta[numSuccesseur]);
                    }
                }
                if (numSommet != i && numSommet != j) { // Exclure source et destination
                    centralite[numSommet] += delta[numSommet];
                }
            }

            // Libération de la mémoire
            free(niveau);
            free(chemins);
            free(delta);
            free(pile);
        }
    }

    // Normalisation de la centralité
    float facteur = (nbSommets - 1) * (nbSommets - 2);
    for (i = 0; i < nbSommets; i++) {
        centralite[i] /= facteur;
        reseau->sommets[i].centralité_intermédiaire = centralite[i];
    }
}

void calculer_centralite_radiale(ReseauTrophique *reseau) {
    for (int i = 0; i < reseau->nbSommets; i++) {
        // Calcul de la centralité radiale
        int degre_entrant = reseau->sommets[i].nbr_pred;
        int degre_sortant = reseau->sommets[i].nbr_succ;
        reseau->sommets[i].centralite_radiale = degre_entrant + degre_sortant;

        // Affichage pour validation
        printf("La CR du sommet %s : Degre entrant = %d, Degre sortant = %d donc la Centralite radiale = %d\n", reseau->sommets[i].nom, degre_entrant,degre_sortant, reseau->sommets[i].centralite_radiale);
    }
}


//Moteur de recherche en fontion du nom, nbr pred et nbr succ
void moteur_de_recherche(ReseauTrophique *reseau) {
    //Initialisation des variables
    int choix;
    int nbr;
    char nom[100];
    int verification = 0;
    int sommet = 0;
    int taille = 0;
    int tab[taille];
    //Boucle de choix du menu
    do {
        printf("\n======== MENU ========\n"
               "Que voulez vous faire ?\n"
           "1 : Rechercher un sommet par son nom\n"
           "2 : Rechercher un sommet par son nbr de predecesseurs\n"
           "3 : Rechercher un sommet par son nbr de successeurs\n"
           "4 : Afficher le niveau trophique des sommets\n"
           "5 : Afficher la centralite radiale des sommets\n"
           "6 : Afficher la centralité intermédiaire du reseau\n"
           "7 : Afficher les chainess alimentaires à partir d'un sommet\n"
           "8 : QUITTER\n");
        scanf("%d",&choix);
        switch (choix) {
            //Recherche en fonction du nom
            case 1:
                system("cls");
                printf("Quel est le nom du sommet que vous rechercher ? (remplacer les espaces par _)\n");
                scanf("%s", nom);
                //Recherche du sommet avec vérification d'existence
                for(int i = 0; i < reseau->nbSommets; i++) {
                    if(strcmp(reseau->sommets[i].nom, nom) == 0) {
                        verification = 1;
                        sommet = i;
                    }
                }
                //Affichage du sommet et de l'ensemble de ses informations
                if(verification == 1) {
                    printf("Votre sommet est : %s\n"
                           "il y a %d predecesseur(s) et %d successeur(s)\n"
                           "il est de niveau trophique %d\n"
                           "et cette espece compte %d membres\n",
                           reseau->sommets[sommet].nom,reseau->sommets[sommet].nbr_pred,reseau->sommets[sommet].nbr_succ,reseau->sommets[sommet].niveauTrophique,reseau->sommets[sommet].nbr_especes);
                }
                //Si inexistence
                else {
                    printf("Votre sommet n'existe pas\n");
                }
                //Remise à 0
                verification = 0;
                break;
            //Recherche en fonction du nombre de predecesseurs
            case 2:
                system("cls");
                printf("Combien de predecesseurs doivent avoir vos sommets ?\n");
                scanf("%d",&nbr);
                //Recherche des sommets avec vérification d'existence
                for(int i = 0; i < reseau->nbSommets; i++) {
                     if(reseau->sommets[i].nbr_pred == nbr) {
                         verification = 1;
                         tab[taille] = i;
                         taille++;
                     }
                }
                //Affichage de la liste des sommets vérifiant le nombre de predecesseurs voulu
                if(verification == 1) {
                     for(int i = 0; i < taille; i++) {
                         for(int j = 0; j < reseau->nbSommets; j++) {
                             if(tab[i] == j) {
                                 printf("le sommet : %s correspond\n",reseau->sommets[j].nom);
                             }
                         }
                     }
                }
                //Si inexistence
                else {
                    printf("Aucun sommet ne correspond\n");
                }
                //Remise à 0
                nbr = 0;
                verification = 0;
                break;
            //Recherche en fonction du nombre de successeurs
            case 3:
                system("cls");
                printf("Combien de successeurs doivent avoir vos sommets ?\n");
                scanf("%d",&nbr);
                //Recherche des sommets avec vérification d'existence
                for(int i = 0; i < reseau->nbSommets; i++) {
                    if(reseau->sommets[i].nbr_succ == nbr) {
                        verification = 1;
                        tab[taille] = i;
                        taille++;
                    }
                }
                //Affichage de la liste des sommets vérifiant le nombre de successeurs voulu
                if(verification == 1) {
                    for(int i = 0; i < taille; i++) {
                        for(int j = 0; j < reseau->nbSommets; j++) {
                            if(tab[i] == j) {
                                printf("le sommet : %s correspond\n",reseau->sommets[j].nom);
                            }
                        }
                    }
                }
                //Si inexistence
                else {
                    printf("Aucun sommet ne correspond\n");
                }
                //Remise à 0
                nbr = 0;
                verification = 0;
                break;
            // Affichage les niveaux trophiques
            case 4:
                system("cls");
                afficher_niveaux_trophiques(reseau);
                break;
            // Affichage la centralite radiale des sommets
            case 5:
                system("cls");
                calculer_centralite_radiale(reseau);
                break;
            // Afficher la centralité intermédiaire du reseau
            case 6:
                system("cls");
                //Calcule de centralité intermédiaire
                float *centralite = (float *)malloc(reseau->nbSommets * sizeof(float));
                calculer_centralite_intermediaire(reseau, centralite);

                for (int i = 0; i < reseau->nbSommets; i++) {
                    printf("Centralité d'intermédiarité pour %s: %f\n", reseau->sommets[i].nom, centralite[i]);
                }

                free(centralite);
                break;
            // Affichage des chaînes alimentaires en fcontion d'un sommet de départ
            case 7:
                system("cls");
                trouverCheminVersProducteurs(reseau);
                break;
        }
    }while(choix != 8);
}

