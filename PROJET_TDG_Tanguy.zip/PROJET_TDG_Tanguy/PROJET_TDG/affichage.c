#include "biblio.h"

//Affichage du réseau
void afficherReseau(ReseauTrophique *reseau) {
    //Calcule de la densité du réseau
    float max_liens = 0;
    max_liens = reseau->nbSommets * (reseau->nbSommets - 1);
    reseau->densité = (float)reseau->nbArcs/max_liens;
    //Affichage des informations relatives au réseau
    printf("Reseau Trophique avec %d sommets, %d arcs et de hauteur throphique : %d et de densité : %0.3f\n",
        reseau->nbSommets, reseau->nbArcs,reseau->hauteur_trophique,reseau->densité);
    //Affichage des sommets du réseau
    printf("Liste des sommets : \n");
    for (int i = 0; i < reseau->nbSommets; i++) {
        printf("Sommet %d: %s, Niveau Trophique: %d,Quantité: %d\n", i, reseau->sommets[i].nom, reseau->sommets[i].niveauTrophique,reseau->sommets[i].nbr_especes);
    }
    //Affichage des aretes du réseau
    printf("Liste des aretes : \n");
    for (int i = 0; i < reseau->nbArcs; i++) {
        printf("Arc %d: de %d a %d, Poids: %.2f\n", i, reseau->arcs[i].from, reseau->arcs[i].to, reseau->arcs[i].poids);
    }
    //Affichage des predecesseurs et des successeurs
    affichagePredecesseuretSuccesseur(reseau);
}

//Affichage des predecesseurs et des successeurs
void affichagePredecesseuretSuccesseur(ReseauTrophique *reseau) {
    //Création des tableaux des predécesseurs et des successeurs
    PredetSucc(reseau);
    //Boucle de sommets
    for(int i = 0;i < reseau->nbSommets; i++) {
        //Affichage des predecesseurs du sommet
        printf("Les predecesseurs de %s sont : \n", reseau->sommets[i].nom);
        //S'il n'a aucun predecesseurs
        if(reseau->sommets[i].nbr_pred == 0) {
            printf("Aucun\n");
        }
        //S'il en a
        else {
            for (int j = 0; j < reseau->sommets[i].nbr_pred; j++) {
                printf("%s\n", reseau->sommets[i].predecesseur[j]->nom);
            }
        }
        //Affichage des successeurs du sommet
        printf("Les successeurs de %s sont : \n", reseau->sommets[i].nom);
        //S'il n'a aucun successeur
        if(reseau->sommets[i].nbr_succ == 0) {
            printf("Aucun\n");
        }
        //S'il en a
        else {
            for (int j = 0; j < reseau->sommets[i].nbr_succ; j++) {
                printf("%s\n", reseau->sommets[i].successeur[j]->nom);
            }
        }
    }
}