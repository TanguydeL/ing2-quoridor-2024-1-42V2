#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAX_NOEUDS 100

// Structure pour représenter un sommet
typedef struct Sommet {
    int sommet;
    struct Sommet* suivant;
    int id;                         // Identifiant du sommet
    int* positions;                 // Les positions du sommet dans les chemins DFS
    int nbPositions;                // Nombre de positions enregistrées
} Sommet;

// Structure pour représenter un graphe
typedef struct Graphe {
    int nombreSommets;
    Sommet* listesAdjacence;        // Pointeur vers un tableau de listes d'adjacence
    Sommet* sommets;                // Pointeur vers un tableau de sommets
    bool* visite;                   // Tableau dynamique de sommets visités
} Graphe;

// Création d'un nouveau nœud
Sommet* creerNoeud(int sommet) {
    Sommet* nouveau = malloc(sizeof(Sommet));
    nouveau->sommet = sommet;
    nouveau->suivant = NULL;
    nouveau->positions = NULL;
    nouveau->nbPositions = 0;
    return nouveau;
}

// Initialisation d'un graphe
Graphe* creerGraphe(int sommets) {
    Graphe* graphe = malloc(sizeof(Graphe));
    graphe->nombreSommets = sommets;

    // Allocation dynamique pour les listes d'adjacence, sommets et visite
    graphe->listesAdjacence = calloc(sommets, sizeof(Sommet));
    graphe->sommets = malloc(sommets * sizeof(Sommet));
    graphe->visite = calloc(sommets, sizeof(bool));

    for (int i = 0; i < sommets; i++) {
        graphe->listesAdjacence[i].suivant = NULL;
        graphe->sommets[i].id = i;
        graphe->sommets[i].positions = NULL;
        graphe->sommets[i].nbPositions = 0;
    }

    return graphe;
}

// Ajout d'une arête
void ajouterArete(Graphe* graphe, int source, int destination) {
    // Ajouter l'arête source -> destination
    Sommet* nouveau = creerNoeud(destination);
    nouveau->suivant = graphe->listesAdjacence[source].suivant;
    graphe->listesAdjacence[source].suivant = nouveau;

    // Ajouter l'arête destination -> source (pour un graphe non orienté)
    nouveau = creerNoeud(source);
    nouveau->suivant = graphe->listesAdjacence[destination].suivant;
    graphe->listesAdjacence[destination].suivant = nouveau;
}

// Fonction pour ajouter une position pour un sommet
void ajouterPosition(Graphe* graphe, int sommet, int position) {
    Sommet* infos = &graphe->sommets[sommet];
    infos->positions = realloc(infos->positions, (infos->nbPositions + 1) * sizeof(int));
    if (infos->positions == NULL) {
        fprintf(stderr, "Erreur : Impossible de réallouer la mémoire pour les positions du sommet %d\n", sommet);
        exit(EXIT_FAILURE);
    }
    infos->positions[infos->nbPositions] = position;
    infos->nbPositions++;
}

// Affichage des positions des sommets
void afficherPositions(Graphe* graphe) {
    printf("\nPositions des sommets dans les chemins DFS :\n");
    for (int i = 0; i < graphe->nombreSommets; i++) {
        Sommet* infos = &graphe->sommets[i];
        printf("Sommet %d : ", infos->id);
        for (int j = 0; j < infos->nbPositions; j++) {
            printf("%d ", infos->positions[j]);
        }
        printf("\n");
    }
}

// Affichage de tous les chemins en DFS
void parcoursProfondeur(Graphe* graphe, int debut, int fin, int chemin[], int indiceChemin) {
    graphe->visite[debut] = true;
    chemin[indiceChemin] = debut;
    ajouterPosition(graphe, debut, indiceChemin); // Collecter la position
    indiceChemin++;

    if (debut == fin) {
        // Afficher le chemin trouvé
        for (int i = 0; i < indiceChemin; i++) {
            printf("%d ", chemin[i]);
        }
        printf("\n");
    } else {
        // Parcourir les voisins
        Sommet* temp = graphe->listesAdjacence[debut].suivant;
        while (temp) {
            int sommetAdj = temp->sommet;
            if (!graphe->visite[sommetAdj]) {
                parcoursProfondeur(graphe, sommetAdj, fin, chemin, indiceChemin);
            }
            temp = temp->suivant;
        }
    }

    // Backtracking
    indiceChemin--;
    graphe->visite[debut] = false;
}

// Comparateur pour qsort
int comparer(const void* a, const void* b) {
    return (*(int*)a - *(int*)b);
}

// Fonction pour trier un tableau dynamique et supprimer les doublons
int* trierEtSupprimerDoublons(int* tableau, int taille, int* nouvelleTaille) {
    if (taille == 0) {
        *nouvelleTaille = 0;
        return NULL;
    }

    // Trier le tableau
    qsort(tableau, taille, sizeof(int), comparer);

    // Allouer un tableau temporaire pour le résultat
    int* resultat = malloc(taille * sizeof(int));
    if (!resultat) {
        fprintf(stderr, "Erreur : Impossible d'allouer de la mémoire.\n");
        exit(EXIT_FAILURE);
    }

    // Supprimer les doublons
    int j = 0;
    resultat[j++] = tableau[0]; // Le premier élément est toujours unique
    for (int i = 1; i < taille; i++) {
        if (tableau[i] != tableau[i - 1]) {
            resultat[j++] = tableau[i];
        }
    }

    // Redimensionner le tableau pour s'ajuster à la nouvelle taille
    resultat = realloc(resultat, j * sizeof(int));
    if (!resultat) {
        fprintf(stderr, "Erreur : Impossible de réallouer la mémoire.\n");
        exit(EXIT_FAILURE);
    }

    *nouvelleTaille = j; // Mise à jour de la nouvelle taille
    return resultat;
}

// Trier et supprimer doublons pour chaque sommet
void tri_init(Graphe* graphe) {
    for (int i = 0; i < graphe->nombreSommets; i++) {
        int nouvelleTaille;
        int* positionsTriees = trierEtSupprimerDoublons(graphe->sommets[i].positions, graphe->sommets[i].nbPositions, &nouvelleTaille);

        // Libérer l'ancienne mémoire
        free(graphe->sommets[i].positions);

        // Réassigner les positions triées sans doublons
        graphe->sommets[i].positions = positionsTriees;
        graphe->sommets[i].nbPositions = nouvelleTaille;

        // Affichage des positions triées et sans doublons
        printf("Sommet %d après tri et suppression des doublons : ", i);
        for (int j = 0; j < nouvelleTaille; j++) {
            printf("%d ", graphe->sommets[i].positions[j]);
        }
        printf("\n");
    }
}


